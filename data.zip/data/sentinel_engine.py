import json

from detect_anomaly import analyze_measure
from threat_engine import calculate_threat


def analyze_sentinel(measure):
    # Analyse environnementale par Isolation Forest V3
    environment = analyze_measure(measure)

    # État de la caméra
    identity = measure.get("identity", "NOT_AVAILABLE")

    # Analyse du niveau de menace
    threat = calculate_threat(
        anomaly=environment["anomaly"],
        motion=measure.get("motion", False),
        distance=measure.get("distance"),
        identity=identity
    )

    return {
        "environment": environment,
        "intrusion": {
            "motion": measure.get("motion", False),
            "distance_cm": measure.get("distance"),
            "identity": identity
        },
        "threat": threat
    }


if __name__ == "__main__":
    # Scénario de démonstration
    measure = {
        "temperature": 24.2,
        "humidity": 50,
        "gas": 181,
        "motion": True,
        "distance": 78,
        "identity": "UNKNOWN"
    }

    result = analyze_sentinel(measure)

    print(json.dumps(result, indent=2, ensure_ascii=False))