"""
SENTINEL-X - Serveur IA de l'equipe Data
Recoit chaque mesure du backend SENTINEL-X sur POST /predict
et renvoie le resultat de l'IA.

Installation (une seule fois) :
    pip install fastapi uvicorn scikit-learn numpy

Lancement :
    uvicorn ia_server:app --host 0.0.0.0 --port 8001

Test : ouvrir http://localhost:8001/docs
"""

from collections import deque

import numpy as np
from fastapi import FastAPI
from pydantic import BaseModel
from sklearn.ensemble import IsolationForest

app = FastAPI(title="SENTINEL-X - IA equipe Data")


# Format EXACT des mesures envoyees par le Raspberry Pi (ne pas changer)
class Mesure(BaseModel):
    temperature: float
    humidity: float
    distance_cm: float = 0.0
    motion_detected: bool = False
    gas_detected: bool = False
    status: str = "NORMAL"


# Historique des mesures pour entrainer le modele
historique = deque(maxlen=3000)
modele = None
compteur = 0


def entrainer():
    """Reentraine l'Isolation Forest sur l'historique."""
    global modele
    X = np.array(historique)
    modele = IsolationForest(contamination=0.01, random_state=42).fit(X)


@app.post("/predict")
def predict(m: Mesure):
    global compteur

    # ---------------------------------------------------------------
    # >>> C'EST ICI QUE VOUS METTEZ VOTRE PROPRE MODELE <<<
    # Remplacez ce bloc par votre logique si vous en avez une.
    # ---------------------------------------------------------------
    x = [m.temperature, m.humidity, m.distance_cm]
    historique.append(x)
    compteur += 1

    # Score de menace a partir des capteurs (0-100)
    score = 0
    raisons = []
    if m.gas_detected:
        score += 40
        raisons.append("Gaz detecte")
    if m.motion_detected:
        score += 30
        raisons.append("Mouvement")
    if 2 <= m.distance_cm < 50:
        score += 20
        raisons.append("Objet proche")
    if m.temperature > 30 or m.humidity > 70:
        score += 10
        raisons.append("Environnement anormal")

    # Detection d'anomalie par IA (apres 50 mesures)
    anomalie = False
    score_ia = 0.0
    if len(historique) >= 50:
        if modele is None or compteur % 30 == 0:
            entrainer()
        score_ia = float(-modele.score_samples([x])[0])
        anomalie = bool(modele.predict([x])[0] == -1)
        if anomalie:
            score = min(100, score + 15)
            raisons.append("Anomalie IA")

    niveau = "FAIBLE" if score < 30 else "MOYEN" if score < 60 else "ELEVE"

    # Format de reponse a garder identique (le dashboard l'affiche)
    return {
        "anomaly": anomalie,
        "score": round(score_ia, 3),
        "threat_score": score,
        "threat_level": niveau,
        "reasons": raisons,
        "model": "IsolationForest" if len(historique) >= 50 else "apprentissage",
    }


@app.get("/")
def accueil():
    return {"status": "IA SENTINEL-X en ligne", "mesures": len(historique)}
