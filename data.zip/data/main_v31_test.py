# COPIE DE TEST : ne pas substituer au backend du Raspberry Pi.
# Lancee localement sur le PC Data (port 8004), avec une base SQLite distincte.
# Ne pas envoyer de mesures au backend reel lors des essais.
"""
SENTINEL-X - Backend FastAPI
- Recoit les mesures du Raspberry Pi (POST /api/v1/alerts)
- Les enregistre dans SQLite (sentinel.db) et genere des evenements
- Sert le dashboard (mesures, historique, evenements, statistiques, IA)

Lancement (depuis le dossier backend) :
  uvicorn main:app --host 0.0.0.0 --port 8000
"""

import asyncio
import csv
import io
import json
import os
import sqlite3
import threading
import time
import urllib.request
from contextlib import asynccontextmanager, contextmanager
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional

import numpy as np
from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import Response
from pydantic import BaseModel
from sklearn.ensemble import IsolationForest

# ---- Configuration ----
DB_PATH = Path(os.environ.get("SENTINEL_DB", Path(__file__).parent / "sentinel_test_v31.db"))
TEMP_ALERT = 30.0          # °C  (memes seuils que firmware/sentinel_pi.py)
HUM_ALERT = 70.0           # %
DIST_ALERT = 50.0          # cm
ONLINE_TIMEOUT_S = 10      # au-dela, le boitier est considere hors ligne
EVENT_COOLDOWN_S = 60      # un meme type d'evenement : au plus 1 fois toutes les 60 s
PRESENCE_END_S = 60        # une presence se termine apres 60 s sans mouvement
AI_MIN_SAMPLES = 50        # nb d'exemples minimum avant d'entrainer l'IA
AI_TRAIN_SAMPLES = 3000    # l'IA apprend sur les N dernieres mesures (~1 h 40 a 2 s par mesure)
AI_RETRAIN_S = 60          # re-entrainement au plus toutes les 60 s
AI_CONTAMINATION = 0.01    # part des mesures que l'IA considere comme anormales (1 %)
AI_DELTA_POINTS = 30       # variation calculee par rapport a la mesure d'il y a 30 points (~1 min)
AI_CONFIRM = 3             # ANOMALIE seulement apres 3 predictions anormales consecutives

# Moteur IA de l'equipe Data (optionnel).
#   None  -> on utilise l'IsolationForest local
#   "http://<IP du PC Data>:<port>/predict" -> on utilise leur resultat
#   (si leur PC ne repond pas, on repasse automatiquement sur l'IA locale)
DATA_AI_URL = os.environ.get("SENTINEL_DATA_AI_URL", "http://127.0.0.1:8003/predict")
DATA_AI_TIMEOUT_S = 1

LEVELS = ("critique", "majeure", "mineure", "information")


# ---------------------------------------------------------------------------
# Base de donnees SQLite
# ---------------------------------------------------------------------------
@contextmanager
def db():
    """Connexion SQLite : une par operation, enregistree (commit) puis fermee automatiquement."""
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row   # permet d'acceder aux colonnes par leur nom
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()


def init_db():
    with db() as conn:
        conn.executescript("""
            CREATE TABLE IF NOT EXISTS measurements (
                id              INTEGER PRIMARY KEY AUTOINCREMENT,
                ts              TEXT NOT NULL,
                temperature     REAL,
                humidity        REAL,
                distance_cm     REAL,
                motion_detected INTEGER,
                gas_detected    INTEGER,
                status          TEXT,
                ai_label        TEXT,
                ai_score        REAL
            );
            CREATE INDEX IF NOT EXISTS idx_measurements_ts ON measurements(ts);

            CREATE TABLE IF NOT EXISTS events (
                id      INTEGER PRIMARY KEY AUTOINCREMENT,
                ts      TEXT NOT NULL,
                level   TEXT NOT NULL,
                type    TEXT NOT NULL,
                message TEXT NOT NULL,
                value   REAL
            );
            CREATE INDEX IF NOT EXISTS idx_events_ts ON events(ts);
        """)
        # Colonnes ajoutees apres coup : on les cree si la base est ancienne
        cols = {r["name"] for r in conn.execute("PRAGMA table_info(measurements)")}
        if "ai_confidence" not in cols:
            conn.execute("ALTER TABLE measurements ADD COLUMN ai_confidence REAL")
        if "ai_source" not in cols:
            conn.execute("ALTER TABLE measurements ADD COLUMN ai_source TEXT")


def now_str():
    # Heure locale, format ISO : "2026-10-08T14:03:12" (triable comme du texte)
    return datetime.now().isoformat(timespec="seconds")


def add_event(level, type_, message, value=None):
    with db() as conn:
        event_id = conn.execute(
            "INSERT INTO events (ts, level, type, message, value) VALUES (?, ?, ?, ?, ?)",
            (now_str(), level, type_, message, value),
        ).lastrowid
    print(f" [{level.upper()}] {message}")
    return event_id


# ---------------------------------------------------------------------------
# Etat en memoire (derniere mesure, connexion, etats precedents)
# ---------------------------------------------------------------------------
latest_data = {
    "temperature": 22.5,
    "humidity": 48.0,
    "distance_cm": 0.0,
    "motion_detected": False,
    "gas_detected": False,
    "status": "NORMAL",
}
last_seen = None            # time.time() de la derniere mesure recue
online = False
prev_flags = {}             # etats du tour precedent, pour detecter les changements
last_event_at = {}          # type -> time.time() du dernier evenement enregistre (anti-repetition)
alert_logged = False        # une alerte a ete enregistree depuis le dernier "Retour a la normale"
presence = None             # presence en cours : {"id": id de l'evenement, "start": ..., "last": ...}
state_lock = threading.Lock()


def compute_flags(d):
    """Quelles conditions d'alerte sont actives pour cette mesure ? (0 = pas de mesure)"""
    return {
        "gaz": bool(d["gas_detected"]),
        "mouvement": bool(d["motion_detected"]),
        "distance": 2.0 <= d["distance_cm"] < DIST_ALERT,
        "temperature": d["temperature"] != 0 and d["temperature"] > TEMP_ALERT,
        "humidite": d["humidity"] != 0 and d["humidity"] > HUM_ALERT,
    }


def fmt_duration(seconds):
    """65 -> "1 min 05 s" ; 3700 -> "1 h 01 min" ; 0 -> "< 2 s" (une seule detection)."""
    seconds = round(seconds)
    if seconds < 2:
        return "< 2 s"
    if seconds < 60:
        return f"{seconds} s"
    if seconds < 3600:
        return f"{seconds // 60} min {seconds % 60:02d} s"
    return f"{seconds // 3600} h {seconds % 3600 // 60:02d} min"


def hhmmss(t):
    return datetime.fromtimestamp(t).strftime("%H:%M:%S")


def update_presence(motion):
    """Regroupe les mouvements consecutifs en un seul evenement « Presence detectee »."""
    global presence
    now = time.time()
    if motion:
        if presence is None:
            event_id = add_event("majeure", "mouvement", f"Présence détectée — en cours (depuis {hhmmss(now)})")
            presence = {"id": event_id, "start": now, "last": now}
        else:
            presence["last"] = now
    elif presence and now - presence["last"] > PRESENCE_END_S:
        end_presence()


def end_presence(note=""):
    """Termine la presence en cours : met a jour son evenement (debut -> fin, duree en secondes)."""
    global presence
    duration = round(presence["last"] - presence["start"])
    message = (f"Présence détectée : {hhmmss(presence['start'])} → {hhmmss(presence['last'])} "
               f"({fmt_duration(duration)}){note}")
    with db() as conn:
        conn.execute("UPDATE events SET message = ?, value = ? WHERE id = ?",
                     (message, round(duration), presence["id"]))
    print(f" [MAJEURE] {message.replace('→', '->')}")   # la console Windows n'affiche pas la fleche
    presence = None


def generate_events(d, flags):
    """Cree un evenement a chaque changement d'etat (front montant), et au retour a la normale.
    Anti-repetition : un meme type n'est enregistre qu'une fois toutes les EVENT_COOLDOWN_S secondes.
    Le mouvement est gere a part (update_presence) : il a son propre debut et sa propre fin."""
    global alert_logged
    update_presence(flags["mouvement"])
    flags = {k: v for k, v in flags.items() if k != "mouvement"}
    rules = {
        "gaz":         ("critique", "Gaz détecté", None),
        "distance":    ("majeure",  f"Objet proche : {d['distance_cm']:.1f} cm", d["distance_cm"]),
        "temperature": ("mineure",  f"Température élevée : {d['temperature']:.1f} °C", d["temperature"]),
        "humidite":    ("mineure",  f"Humidité élevée : {d['humidity']:.1f} %", d["humidity"]),
    }
    for key, active in flags.items():
        if active and not prev_flags.get(key, False):
            if time.time() - last_event_at.get(key, 0) < EVENT_COOLDOWN_S:
                continue        # deja enregistre il y a moins de EVENT_COOLDOWN_S : on ignore
            level, message, value = rules[key]
            add_event(level, key, message, value)
            last_event_at[key] = time.time()
            alert_logged = True

    # "Retour a la normale" seulement si une alerte a vraiment ete enregistree avant
    prev = {k: v for k, v in prev_flags.items() if k != "mouvement"}
    if any(prev.values()) and not any(flags.values()) and alert_logged:
        add_event("information", "normal", "Retour à la normale")
        alert_logged = False


# ---------------------------------------------------------------------------
# IA : detection d'anomalies (IsolationForest)
# ---------------------------------------------------------------------------
ai_model = None
ai_trained_at = 0.0
ai_train_count = 0
ai_spread = 1.0             # dispersion des scores d'entrainement (pour la confiance)
ai_lock = threading.Lock()


VALID = "temperature != 0 AND humidity != 0"   # mesures ou le DHT22 a repondu


def ai_vector(cur, prev):
    """Ce que l'IA regarde : les valeurs actuelles + leur variation sur ~1 minute.
    Une derive lente donne une petite variation (normal), un changement brutal une grande (suspect)."""
    return [
        cur["temperature"], cur["humidity"], cur["distance_cm"],
        cur["temperature"] - prev["temperature"],
        cur["humidity"] - prev["humidity"],
        cur["distance_cm"] - prev["distance_cm"],
    ]


def train_ai_if_needed():
    """(Re)entraine le modele sur l'historique si besoin. Renvoie le nb d'exemples utilisables."""
    global ai_model, ai_trained_at, ai_train_count, ai_spread
    with db() as conn:
        rows = conn.execute(
            f"SELECT temperature, humidity, distance_cm FROM measurements WHERE {VALID} "
            "ORDER BY id DESC LIMIT ?",
            (AI_TRAIN_SAMPLES + AI_DELTA_POINTS,),
        ).fetchall()
    rows = rows[::-1]   # de la plus ancienne a la plus recente
    # Chaque exemple = une mesure + sa variation par rapport a celle d'il y a AI_DELTA_POINTS points
    examples = [ai_vector(rows[i], rows[i - AI_DELTA_POINTS]) for i in range(AI_DELTA_POINTS, len(rows))]
    count = len(examples)
    if count < AI_MIN_SAMPLES:
        return count
    with ai_lock:
        if ai_model is None or time.time() - ai_trained_at > AI_RETRAIN_S:
            X = np.array(examples)
            model = IsolationForest(n_estimators=100, contamination=AI_CONTAMINATION, random_state=42)
            model.fit(X)
            ai_spread = float(np.std(model.decision_function(X))) or 1.0
            ai_model, ai_trained_at, ai_train_count = model, time.time(), count
    return count


def predict(d):
    """Renvoie (label, score, confiance) pour une mesure, ou None si l'IA n'est pas prete.
    La mesure d n'est pas encore en base : la mesure d'il y a 30 points est donc la 30e plus recente."""
    if ai_model is None or d["temperature"] == 0 or d["humidity"] == 0:
        return None
    with db() as conn:
        prev = conn.execute(
            f"SELECT temperature, humidity, distance_cm FROM measurements WHERE {VALID} "
            "ORDER BY id DESC LIMIT 1 OFFSET ?",
            (AI_DELTA_POINTS - 1,),
        ).fetchone()
    if prev is None:
        return None
    with ai_lock:
        x = np.array([ai_vector(d, prev)])
        decision = float(ai_model.decision_function(x)[0])   # < 0 = anomalie
        score = float(-ai_model.score_samples(x)[0])          # ~0.5 normal, proche de 1 = anomalie
    label = "ANOMALIE" if decision < 0 else "NORMAL"
    # Confiance : plus la mesure est loin de la frontiere normal/anomalie, plus on est sur
    confidence = min(0.99, 0.5 + abs(decision) / (2 * ai_spread))
    return label, round(score, 3), round(confidence, 2)


def predict_data_ai(d):
    """Adaptateur V3.1, conserve les etats explicites de l'IA Data."""
    body = json.dumps({k: d[k] for k in
                       ("temperature", "humidity", "distance_cm", "motion_detected", "gas_detected", "status")})
    req = urllib.request.Request(DATA_AI_URL, data=body.encode(), method="POST",
                                 headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=DATA_AI_TIMEOUT_S) as res:
        r = json.load(res)
    if not isinstance(r.get("anomaly"), bool):
        raise ValueError(f"reponse inattendue du moteur Data : {r}")
    ai_state = r.get("ai_state", "ready")
    sensor_status = r.get("sensor_status", "VALID")
    level = r.get("level")
    if level == "CRITIQUE":
        label = "CRITIQUE"
    elif sensor_status == "INVALID" or ai_state == "invalid_measurement":
        label = "MESURE_INVALIDE"
    elif level == "ALERTE":
        label = "ALERTE"
    elif level == "VIGILANCE":
        label = "VIGILANCE"
    elif ai_state == "learning":
        label = "APPRENTISSAGE"
    else:
        label = "ANOMALIE" if r["anomaly"] else "NORMAL"
    return {
        "label": label, "raw_label": label, "streak": 0,
        "score": None if r.get("score") is None else round(float(r["score"]), 3),
        "confidence": r.get("confidence"),
        "threat_score": r.get("threat_score"),
        "threat_level": r.get("threat_level"),
        "reasons": r.get("reasons") or [], "model": r.get("model"),
        "ai_state": ai_state, "sensor_status": sensor_status,
        "level": r.get("level"), "alert_type": r.get("alert_type"),
    }


last_ai = None              # derniere prediction (calculee a chaque mesure recue)
ai_streak = 0               # nb de predictions anormales consecutives


def run_ai(d):
    """Choisit le moteur : Data si DATA_AI_URL est defini et repond, sinon IsolationForest local.
    Renvoie un dict, ou None si aucune prediction n'est possible (apprentissage en cours)."""
    global ai_streak
    source = "local"
    if DATA_AI_URL:
        try:
            # Le resultat de l'equipe Data est affiche tel quel (pas de confirmation sur 3 mesures)
            return {**predict_data_ai(d), "source": "data", "ts": now_str()}
        except Exception as e:
            print(f" IA Data injoignable ({e.__class__.__name__}) -> IA locale")
            source = "local (secours)"

    train_ai_if_needed()
    pred = predict(d)
    if pred is None:
        return None

    # Confirmation : une seule prediction anormale ne suffit pas, il en faut AI_CONFIRM d'affilee
    raw_label = pred[0]
    ai_streak = ai_streak + 1 if raw_label == "ANOMALIE" else 0
    label = "ANOMALIE" if ai_streak >= AI_CONFIRM else "NORMAL"
    return {"label": label, "raw_label": raw_label, "streak": min(ai_streak, AI_CONFIRM),
            "score": pred[1], "confidence": pred[2], "source": source, "ts": now_str(),
            "threat_score": None, "threat_level": None, "reasons": [], "model": "IsolationForest",
             "ai_state": "ready", "sensor_status": "VALID",
             "level": None, "alert_type": None}


# ---------------------------------------------------------------------------
# Surveillance de la connexion du boitier (tache de fond)
# ---------------------------------------------------------------------------
async def watch_online():
    global online
    while True:
        await asyncio.sleep(2)
        with state_lock:
            if presence and time.time() - presence["last"] > PRESENCE_END_S:
                end_presence()
            if online and last_seen and time.time() - last_seen > ONLINE_TIMEOUT_S:
                online = False
                add_event("information", "connexion", "Boîtier hors ligne")


@asynccontextmanager
async def lifespan(app):
    global latest_data
    init_db()
    with db() as conn:
        conn.execute("UPDATE events SET message = REPLACE(message, '— en cours', '— fin inconnue (serveur redémarré)') "
                     "WHERE type = 'mouvement' AND message LIKE '%— en cours%'")
    # Au redemarrage, on reprend la derniere mesure connue
    with db() as conn:
        row = conn.execute("SELECT * FROM measurements ORDER BY id DESC LIMIT 1").fetchone()
    if row:
        latest_data = {
            "temperature": row["temperature"],
            "humidity": row["humidity"],
            "distance_cm": row["distance_cm"],
            "motion_detected": bool(row["motion_detected"]),
            "gas_detected": bool(row["gas_detected"]),
            "status": row["status"],
        }
    task = asyncio.create_task(watch_online())
    yield
    task.cancel()


app = FastAPI(title="Sentinel-X API", lifespan=lifespan)

# Autoriser les requêtes du Dashboard (CORS)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# Modèle pour les données du Raspberry Pi
class AlertPayload(BaseModel):
    temperature: float
    humidity: float
    distance_cm: float
    motion_detected: bool
    gas_detected: bool = False
    status: Optional[str] = "NORMAL"


@app.get("/")
def root():
    return {"status": "Serveur Sentinel-X opérationnel"}


# Route pour recevoir les données du Raspberry Pi (format inchange)
@app.post("/api/v1/alerts")
def receive_alert(data: AlertPayload):
    global latest_data, last_seen, online, prev_flags, last_ai
    d = data.dict()

    with state_lock:
        latest_data = d
        last_seen = time.time()
        if not online:
            online = True
            add_event("information", "connexion", "Boîtier en ligne")
        flags = compute_flags(d)
        generate_events(d, flags)
        prev_flags = flags

    pred = run_ai(d)
    if pred:
        last_ai = pred
    with db() as conn:
        conn.execute(
            "INSERT INTO measurements (ts, temperature, humidity, distance_cm, motion_detected, "
            "gas_detected, status, ai_label, ai_score, ai_confidence, ai_source) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (now_str(), d["temperature"], d["humidity"], d["distance_cm"],
             int(d["motion_detected"]), int(d["gas_detected"]), d["status"],
             pred and pred["label"], pred and pred["score"],
             pred and pred["confidence"], pred and pred["source"]),
        )

    print(f" Données reçues : {latest_data}")
    return {"status": "success", "received": latest_data}


# Route lue par app.js pour le Dashboard (format inchange)
@app.get("/api/v1/data")
def get_latest_data():
    return latest_data


@app.get("/api/v1/history")
def get_history(minutes: int = Query(30, ge=1, le=1440)):
    """Mesures des N dernieres minutes, de la plus ancienne a la plus recente."""
    since = (datetime.now() - timedelta(minutes=minutes)).isoformat(timespec="seconds")
    with db() as conn:
        rows = conn.execute(
            "SELECT ts, temperature, humidity, distance_cm, motion_detected, gas_detected, status "
            "FROM measurements WHERE ts >= ? ORDER BY id",
            (since,),
        ).fetchall()
    return [
        {**dict(r), "motion_detected": bool(r["motion_detected"]), "gas_detected": bool(r["gas_detected"])}
        for r in rows
    ]


@app.get("/api/v1/events")
def get_events(level: Optional[str] = None, limit: int = Query(50, ge=1, le=1000)):
    """Evenements du plus recent au plus ancien, filtrables par niveau."""
    if level and level not in LEVELS:
        raise HTTPException(400, f"level doit etre l'un de : {', '.join(LEVELS)}")
    with db() as conn:
        if level:
            rows = conn.execute(
                "SELECT * FROM events WHERE level = ? ORDER BY id DESC LIMIT ?", (level, limit)
            ).fetchall()
        else:
            rows = conn.execute("SELECT * FROM events ORDER BY id DESC LIMIT ?", (limit,)).fetchall()
    return [dict(r) for r in rows]


@app.get("/api/v1/events/export")
def export_events():
    """Tous les evenements en CSV (separateur ';' pour Excel en francais)."""
    with db() as conn:
        rows = conn.execute("SELECT ts, level, type, message, value FROM events ORDER BY id").fetchall()
    buf = io.StringIO()
    writer = csv.writer(buf, delimiter=";")
    writer.writerow(["horodatage", "niveau", "type", "message", "valeur"])
    for r in rows:
        writer.writerow([r["ts"], r["level"], r["type"], r["message"], "" if r["value"] is None else r["value"]])
    filename = f"sentinel_events_{datetime.now():%Y%m%d_%H%M}.csv"
    return Response(
        content=buf.getvalue().encode("utf-8-sig"),   # BOM : Excel affiche bien les accents
        media_type="text/csv",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )


@app.delete("/api/v1/events")
def clear_events():
    with db() as conn:
        deleted = conn.execute("DELETE FROM events").rowcount
    return {"status": "success", "deleted": deleted}


@app.get("/api/v1/stats")
def get_stats():
    today = datetime.now().strftime("%Y-%m-%d")
    with db() as conn:
        rows = conn.execute(
            "SELECT level, COUNT(*) AS n FROM events WHERE ts >= ? GROUP BY level", (today,)
        ).fetchall()
        motions = conn.execute(
            "SELECT COUNT(*) FROM events WHERE ts >= ? AND type = 'mouvement'", (today,)
        ).fetchone()[0]
        last = conn.execute("SELECT ts FROM measurements ORDER BY id DESC LIMIT 1").fetchone()
    by_level = {lvl: 0 for lvl in LEVELS}
    for r in rows:
        by_level[r["level"]] = r["n"]
    return {
        "alerts_today": by_level,
        "events_today": sum(by_level.values()),
        "motions_today": motions,
        "last_measurement": last["ts"] if last else None,
        "online": bool(last_seen and time.time() - last_seen < ONLINE_TIMEOUT_S),
    }


@app.get("/api/v1/ai/status")
def get_ai_status(history: int = Query(20, ge=0, le=500)):
    """Avis de l'IA sur la derniere mesure + historique des predictions."""
    engine = "data" if DATA_AI_URL else "local"
    with db() as conn:
        rows = conn.execute(
            "SELECT ts, ai_label, ai_score, ai_confidence, ai_source FROM measurements "
            "WHERE ai_label IS NOT NULL ORDER BY id DESC LIMIT ?",
            (history,),
        ).fetchall()
    hist = [{"ts": r["ts"], "label": r["ai_label"], "score": r["ai_score"],
             "confidence": r["ai_confidence"], "source": r["ai_source"]} for r in rows]

    if last_ai is None:
        # Pas encore de prediction : l'IA locale apprend (il lui faut AI_MIN_SAMPLES mesures)
        return {
            "status": "apprentissage en cours",
            "engine": engine,
            "samples": train_ai_if_needed(),
            "samples_needed": AI_MIN_SAMPLES,
            "history": hist,
        }
    return {
        "status": last_ai["label"],
        "raw_label": last_ai["raw_label"],         # avis brut de la derniere prediction
        "streak": last_ai["streak"],               # predictions anormales d'affilee
        "confirm_needed": AI_CONFIRM,
        "score": last_ai["score"],
        "confidence": last_ai["confidence"],
        "threat_score": last_ai["threat_score"],   # fournis par le moteur Data uniquement
        "threat_level": last_ai["threat_level"],
        "reasons": last_ai["reasons"],
        "model": last_ai["model"],
        "ai_state": last_ai.get("ai_state"),
        "sensor_status": last_ai.get("sensor_status"),
        "level": last_ai.get("level"),
        "alert_type": last_ai.get("alert_type"),
        "source": last_ai["source"],
        "engine": engine,
        "predicted_at": last_ai["ts"],
        "samples": ai_train_count,
        "samples_needed": AI_MIN_SAMPLES,
        "trained_at": datetime.fromtimestamp(ai_trained_at).isoformat(timespec="seconds") if ai_trained_at else None,
        "history": hist,
    }
