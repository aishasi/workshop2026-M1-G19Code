"""
SENTINEL-X - Serveur IA de l'equipe Data (V2)
Utilise le moteur de menace de l'equipe (threat_engine.calculate_threat)
et une Isolation Forest avec les memes variables temporelles que la V3
(variations + moyennes glissantes), adaptee aux VRAIS capteurs du Pi :
  - le gaz du Pi est binaire (gas_detected), pas une valeur analogique,
    donc il n'entre pas dans le modele : il est traite comme une alerte directe.

Lancement (dans le dossier sentinel-x-data) :
    uvicorn ia_server_v2:app --host 0.0.0.0 --port 8001
"""

from collections import deque

import numpy as np
from fastapi import FastAPI
from pydantic import BaseModel
from sklearn.ensemble import IsolationForest
from sklearn.preprocessing import StandardScaler

from threat_engine import calculate_threat

app = FastAPI(title="SENTINEL-X - IA equipe Data (V2)")


# Format EXACT des mesures envoyees par le backend SENTINEL-X (ne pas changer)
class Mesure(BaseModel):
    temperature: float
    humidity: float
    distance_cm: float = 0.0
    motion_detected: bool = False
    gas_detected: bool = False
    status: str = "NORMAL"


WINDOW = 6            # meme fenetre glissante que la V3
MIN_TRAIN = 100       # mesures avant la premiere prediction
RETRAIN_EVERY = 60    # reentrainement toutes les 60 mesures (~2 min)

brut = deque(maxlen=WINDOW)          # dernieres mesures brutes
features_hist = deque(maxlen=3000)   # historique des variables pour l'entrainement
modele, scaler = None, None
compteur = 0


def calculer_features(temp, hum):
    """Memes variables que prepare_features.py, sans le gaz."""
    brut.append((temp, hum))
    if len(brut) < WINDOW:
        return None
    t = [b[0] for b in brut]
    h = [b[1] for b in brut]
    return [
        temp,
        hum,
        t[-1] - t[-2],          # temp_change
        h[-1] - h[-2],          # humidity_change
        float(np.mean(t)),      # temp_rolling_mean
        float(np.mean(h)),      # humidity_rolling_mean
    ]


def entrainer():
    global modele, scaler
    X = np.array(features_hist)
    scaler = StandardScaler().fit(X)
    modele = IsolationForest(
        n_estimators=200, contamination=0.01, random_state=42
    ).fit(scaler.transform(X))


@app.post("/predict")
def predict(m: Mesure):
    global compteur
    compteur += 1

    # 1. Anomalie environnementale (Isolation Forest V3 adaptee)
    anomalie, score_ia, confiance = False, 0.0, 0.0
    feats = calculer_features(m.temperature, m.humidity)
    if feats is not None:
        features_hist.append(feats)
        if len(features_hist) >= MIN_TRAIN:
            if modele is None or compteur % RETRAIN_EVERY == 0:
                entrainer()
            Xs = scaler.transform([feats])
            score_ia = float(modele.decision_function(Xs)[0])
            anomalie = bool(modele.predict(Xs)[0] == -1)
            confiance = round(min(1.0, abs(score_ia) * 5), 2)

    # 2. Distance : 0 = mesure invalide pour le Pi
    distance = m.distance_cm if m.distance_cm >= 2 else None

    # 3. Moteur de menace de l'equipe (pas de camera -> identite non disponible)
    threat = calculate_threat(
        anomaly=anomalie,
        motion=m.motion_detected,
        distance=distance,
        identity="NOT_AVAILABLE",
    )

    # 4. Gaz : capteur binaire -> alerte critique directe
    if m.gas_detected:
        threat["score"] = max(threat["score"], 80)
        threat["level"] = "CRITIQUE"
        threat["alert_type"] = "GAZ"
        threat["reasons"].insert(0, "Gaz detecte")

    # Correspondance avec les niveaux affiches par le dashboard
    niveau_dashboard = {
        "NORMAL": "FAIBLE",
        "VIGILANCE": "MOYEN",
        "ALERTE": "ELEVE",
        "CRITIQUE": "ELEVE",
    }[threat["level"]]

    return {
        "anomaly": anomalie,
        "score": round(score_ia, 4),
        "confidence": confiance,
        "threat_score": threat["score"],
        "threat_level": niveau_dashboard,
        "level": threat["level"],              # niveau detaille de l'equipe Data
        "alert_type": threat["alert_type"],
        "reasons": threat["reasons"],
        "model": "IsolationForest V3 (temps reel)" if modele else "apprentissage",
    }


@app.get("/")
def accueil():
    return {
        "status": "IA SENTINEL-X V2 en ligne",
        "mesures": compteur,
        "modele_pret": modele is not None,
    }
