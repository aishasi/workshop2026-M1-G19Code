"""SENTINEL-X Guardian V2 — affichage explicable, lecture seule du backend."""
import json
import time
import urllib.request
from datetime import datetime
from pathlib import Path

import cv2

BACKEND_URL = "http://192.168.137.141:8000"
REFRESH_SECONDS = 1.0
TIMEOUT_SECONDS = 1.0
STALE_SECONDS = 10.0
MODEL_PATH = Path(__file__).resolve().parent / "models" / "camera" / "face_detection_yunet_2023mar.onnx"

COLORS = {
    "NORMAL": (80, 220, 80),
    "VIGILANCE": (0, 220, 255),
    "ALERTE": (0, 140, 255),
    "CRITIQUE": (0, 0, 255),
}


def get_json(path):
    with urllib.request.urlopen(BACKEND_URL + path, timeout=TIMEOUT_SECONDS) as response:
        return json.load(response)


def draw_text(frame, text, y, color=(255, 255, 255), scale=0.55):
    # OpenCV putText ne gere pas correctement les accents : textes d'affichage ASCII.
    cv2.putText(frame, text, (18, y), cv2.FONT_HERSHEY_SIMPLEX, scale, (0, 0, 0), 4, cv2.LINE_AA)
    cv2.putText(frame, text, (18, y), cv2.FONT_HERSHEY_SIMPLEX, scale, color, 2, cv2.LINE_AA)


def normalize_reason(reason):
    """Convertit les explications existantes en libelles courts lisibles sur video."""
    import unicodedata
    raw = str(reason)
    plain = ''.join(c for c in unicodedata.normalize('NFKD', raw) if not unicodedata.combining(c))
    lower = plain.lower()
    if 'gaz' in lower:
        return 'Signal gaz detecte'
    if 'mouvement' in lower:
        return 'Mouvement detecte (PIR)'
    if 'distance' in lower or 'proche' in lower or 'proximite' in lower:
        return 'Objet proche (ultrason)'
    if 'anomal' in lower:
        return 'Anomalie environnementale IA'
    if 'identit' in lower or 'unknown' in lower:
        return 'Identite non reconnue (theorique)'
    return plain[:55]


def prediction_valid(ai):
    if not isinstance(ai, dict) or ai.get('source') != 'data':
        return False
    if ai.get('threat_score') is None or not ai.get('predicted_at'):
        return False
    try:
        age = (datetime.now() - datetime.fromisoformat(ai['predicted_at'])).total_seconds()
        return -5 <= age <= STALE_SECONDS
    except (TypeError, ValueError):
        return False


def main():
    if not MODEL_PATH.exists():
        raise FileNotFoundError(f'Modele YuNet introuvable : {MODEL_PATH}')

    detector = cv2.FaceDetectorYN.create(str(MODEL_PATH), '', (320, 320), 0.8, 0.3, 5000)
    camera = cv2.VideoCapture(0, cv2.CAP_DSHOW)
    if not camera.isOpened():
        raise RuntimeError('Camera inaccessible')

    last_poll = 0.0
    measurements = None
    ai = None
    backend_ok = False
    last_error = ''
    print('=== SENTINEL-X GUARDIAN V2 ===')
    print('Backend en lecture seule :', BACKEND_URL)
    print('Appuie sur Q pour quitter.')

    try:
        while True:
            ok, frame = camera.read()
            if not ok:
                print('Erreur de lecture camera')
                break

            now = time.monotonic()
            if now - last_poll >= REFRESH_SECONDS:
                last_poll = now
                try:
                    measurements = get_json('/api/v1/data')
                    ai = get_json('/api/v1/ai/status?history=0')
                    backend_ok = True
                    last_error = ''
                except (OSError, ValueError, KeyError) as exc:
                    backend_ok = False
                    last_error = type(exc).__name__

            h, w = frame.shape[:2]
            detector.setInputSize((w, h))
            _, faces = detector.detect(frame)
            count = 0 if faces is None else len(faces)

            if faces is not None:
                for face in faces:
                    x, y, fw, fh = map(int, face[:4])
                    cv2.rectangle(frame, (x, y), (x + fw, y + fh), (0, 255, 0), 2)

            panel_h = min(h, 388)
            panel_w = min(w, 560)
            overlay = frame.copy()
            cv2.rectangle(overlay, (0, 0), (panel_w, panel_h), (18, 22, 27), -1)
            cv2.addWeighted(overlay, 0.78, frame, 0.22, 0, frame)

            draw_text(frame, 'SENTINEL-X GUARDIAN | ANALYSE', 29, (90, 255, 90), 0.64)
            draw_text(frame, f'Visages detectes : {count}', 59)
            draw_text(frame, 'Camera : PRESENCE VISUELLE' if count else 'Camera : AUCUN VISAGE', 88,
                      (0, 220, 255) if count else (110, 230, 110))

            if not backend_ok:
                draw_text(frame, 'Backend : INJOIGNABLE', 128, (0, 0, 255))
                draw_text(frame, 'Menace : INDISPONIBLE', 163, (0, 0, 255))
                draw_text(frame, 'Aucun niveau de securite deduit', 199, (0, 220, 255))
                if last_error:
                    draw_text(frame, f'Erreur : {last_error}', 231)
            else:
                d = measurements or {}
                motion = bool(d.get('motion_detected'))
                gas = bool(d.get('gas_detected'))
                draw_text(frame, f'PIR : {"OUI" if motion else "NON"} | Gaz : {"OUI" if gas else "NON"}', 119)
                temp, hum = d.get('temperature'), d.get('humidity')
                if isinstance(temp, (int, float)) and isinstance(hum, (int, float)):
                    draw_text(frame, f'Temp : {temp:.1f} C | Humidite : {hum:.1f} %', 148)
                dist = d.get('distance_cm')
                if isinstance(dist, (int, float)) and dist >= 2:
                    draw_text(frame, f'Distance : {dist:.1f} cm', 177)
                else:
                    draw_text(frame, 'Distance : non disponible', 177)

                if prediction_valid(ai):
                    level = str(ai.get('level') or '').upper()
                    score = max(0, min(100, int(ai['threat_score'])))
                    if level in COLORS:
                        draw_text(frame, f'MENACE : {level} ({score}/100)', 213, COLORS[level], 0.65)
                        draw_text(frame, f'Type : {ai.get("alert_type") or "INCONNU"}', 243)
                        reasons = ai.get('reasons') or []
                        if not isinstance(reasons, list):
                            reasons = []
                        draw_text(frame, 'JUSTIFICATION :', 276, (0, 220, 255))
                        if reasons:
                            for i, reason in enumerate(reasons[:3]):
                                draw_text(frame, '- ' + normalize_reason(reason), 303 + 25 * i, scale=0.48)
                            if len(reasons) > 3:
                                draw_text(frame, f'... et {len(reasons) - 3} autre(s)', 378, scale=0.44)
                        else:
                            draw_text(frame, '- Aucun signal de menace signale', 303, scale=0.48)
                        draw_text(frame, 'Source : IA equipe Data', min(h - 12, 378), (180, 240, 180), 0.45)
                    else:
                        draw_text(frame, 'Menace : NIVEAU INCONNU', 213, (0, 220, 255))
                else:
                    draw_text(frame, 'Menace : NON DISPONIBLE', 213, (0, 220, 255))
                    draw_text(frame, 'Prediction IA absente ou ancienne', 244)
                    draw_text(frame, f'Source : {(ai or {}).get("source") or "aucune"}', 275)

            cv2.imshow('SENTINEL-X | Guardian V2', frame)
            if cv2.waitKey(1) & 0xFF == ord('q'):
                break
    finally:
        camera.release()
        cv2.destroyAllWindows()
        print('SENTINEL-X Guardian V2 arrete.')


if __name__ == '__main__':
    main()
