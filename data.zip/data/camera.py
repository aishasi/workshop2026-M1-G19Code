
import cv2
import requests
import time
from pathlib import Path

from threat_engine import calculate_threat


# ==========================================
# 1. CONFIGURATION SENTINEL-X
# ==========================================

BASE_DIR = Path(__file__).resolve().parent

BACKEND_URL = "http://192.168.137.141:8000/api/v1/identity"

YUNET_PATH = (
    BASE_DIR
    / "models"
    / "camera"
    / "face_detection_yunet_2023mar.onnx"
)

SFACE_PATH = (
    BASE_DIR
    / "models"
    / "camera"
    / "face_recognition_sface_2021dec.onnx"
)

AUTHORIZED_DIR = BASE_DIR / "authorized_faces"

SIMILARITY_THRESHOLD = 0.36
DETECTION_THRESHOLD = 0.85
SEND_INTERVAL = 2.0

_last_send = 0.0

print("=== SENTINEL-X GUARDIAN ===")
print("Initialisation de la reconnaissance faciale...")


# ==========================================
# 2. ENVOI DE L'IDENTITE AU BACKEND
# ==========================================

def send_identity(name, similarity):
    global _last_send

    now = time.monotonic()

    if now - _last_send < SEND_INTERVAL:
        return

    identity = (
        "UNKNOWN"
        if name == "INCONNU"
        else "AUTHORIZED"
    )

    payload = {
        "identity": identity,
        "name": name,
        "similarity": round(
            max(0.0, min(1.0, float(similarity))),
            2
        ),
    }

    try:
        response = requests.post(
            BACKEND_URL,
            json=payload,
            timeout=0.5
        )

        response.raise_for_status()

        _last_send = now

        print(
            f"[BACKEND] Identite envoyee : {identity} | "
            f"Nom : {name} | "
            f"Similarite : {payload['similarity']}"
        )

    except requests.RequestException as error:
        print(f"[BACKEND] Erreur : {error}")


# ==========================================
# 3. CHARGEMENT DES MODELES
# ==========================================

if not YUNET_PATH.exists():
    raise FileNotFoundError(
        f"Modele YuNet introuvable : {YUNET_PATH}"
    )

if not SFACE_PATH.exists():
    raise FileNotFoundError(
        f"Modele SFace introuvable : {SFACE_PATH}"
    )

detector = cv2.FaceDetectorYN.create(
    str(YUNET_PATH),
    "",
    (320, 320),
    DETECTION_THRESHOLD,
    0.3,
    5000
)

recognizer = cv2.FaceRecognizerSF.create(
    str(SFACE_PATH),
    ""
)

COSINE_METRIC = cv2.FaceRecognizerSF_FR_COSINE


# ==========================================
# 4. DETECTION DANS LES PHOTOS
# ==========================================

def detect_reference_face(photo):

    original_height, original_width = photo.shape[:2]

    max_dimension = 1200

    scale = min(
        1.0,
        max_dimension / max(
            original_width,
            original_height
        )
    )

    if scale < 1.0:
        working = cv2.resize(
            photo,
            None,
            fx=scale,
            fy=scale
        )
    else:
        working = photo.copy()

    thresholds = [0.85, 0.70, 0.50]

    for threshold in thresholds:

        detector.setScoreThreshold(threshold)

        height, width = working.shape[:2]
        detector.setInputSize((width, height))

        _, faces = detector.detect(working)

        if faces is not None and len(faces) > 0:

            best_face = max(
                faces,
                key=lambda face: float(face[-1])
            ).copy()

            if scale < 1.0:
                best_face[:14] /= scale

            detector.setScoreThreshold(
                DETECTION_THRESHOLD
            )

            return best_face

    detector.setScoreThreshold(
        DETECTION_THRESHOLD
    )

    return None


# ==========================================
# 5. CHARGEMENT DES PERSONNES AUTORISEES
# ==========================================

authorized_faces = []

if not AUTHORIZED_DIR.exists():
    raise FileNotFoundError(
        f"Dossier introuvable : {AUTHORIZED_DIR}"
    )

for photo_path in sorted(AUTHORIZED_DIR.iterdir()):

    if photo_path.suffix.lower() not in (
        ".jpg",
        ".jpeg",
        ".png"
    ):
        continue

    photo = cv2.imread(str(photo_path))

    if photo is None:
        print(
            f"[ERREUR] Photo illisible : {photo_path.name}"
        )
        continue

    reference_face = detect_reference_face(photo)

    if reference_face is None:
        print(
            f"[ATTENTION] Aucun visage detecte "
            f"dans : {photo_path.name}"
        )
        continue

    try:
        aligned = recognizer.alignCrop(
            photo,
            reference_face
        )

        feature = recognizer.feature(
            aligned
        )

    except cv2.error as error:
        print(
            f"[ERREUR] SFace : "
            f"{photo_path.name} : {error}"
        )
        continue

    name = photo_path.stem

    authorized_faces.append({
        "name": name,
        "feature": feature
    })

    print(
        f"Photo chargee : {photo_path.name} "
        f"-> personne : {name}"
    )

if not authorized_faces:
    raise RuntimeError(
        "Aucun visage autorise charge. "
        "Verifie les photos du dossier authorized_faces."
    )

print(
    f"{len(authorized_faces)} photo(s) "
    "de reference chargee(s)."
)


# ==========================================
# 6. RECONNAISSANCE FACIALE SFACE
# ==========================================

def recognize_face(frame, face):

    try:
        aligned = recognizer.alignCrop(
            frame,
            face
        )

        feature = recognizer.feature(
            aligned
        )

    except cv2.error as error:
        print(
            f"[ERREUR] Reconnaissance : {error}"
        )
        return None

    best_name = "INCONNU"
    best_similarity = -1.0

    for person in authorized_faces:

        similarity = float(
            recognizer.match(
                feature,
                person["feature"],
                COSINE_METRIC
            )
        )

        if similarity > best_similarity:
            best_similarity = similarity
            best_name = person["name"]

    if best_similarity >= SIMILARITY_THRESHOLD:
        return {
            "name": best_name,
            "similarity": best_similarity,
            "identity": "AUTHORIZED"
        }

    return {
        "name": "INCONNU",
        "similarity": best_similarity,
        "identity": "UNKNOWN"
    }


# ==========================================
# 7. INITIALISATION DE LA WEBCAM
# ==========================================

def open_camera():

    # Premier essai : Media Foundation
    cam = cv2.VideoCapture(
        0,
        cv2.CAP_MSMF
    )

    if cam.isOpened():
        cam.set(
            cv2.CAP_PROP_FRAME_WIDTH,
            640
        )

        cam.set(
            cv2.CAP_PROP_FRAME_HEIGHT,
            480
        )

        print(
            "[CAMERA] Backend MSMF active."
        )

        return cam

    cam.release()

    # Deuxieme essai : DirectShow
    cam = cv2.VideoCapture(
        0,
        cv2.CAP_DSHOW
    )

    if cam.isOpened():

        cam.set(
            cv2.CAP_PROP_FRAME_WIDTH,
            640
        )

        cam.set(
            cv2.CAP_PROP_FRAME_HEIGHT,
            480
        )

        print(
            "[CAMERA] Backend DirectShow active."
        )

        return cam

    cam.release()

    raise RuntimeError(
        "Aucune webcam accessible."
    )


camera = open_camera()

print("Camera active !")
print("Appuie sur Q pour quitter.")


# ==========================================
# 8. SURVEILLANCE EN TEMPS REEL
# ==========================================

try:
    while True:

        success, frame = camera.read()

        if not success or frame is None:
            print(
                "[CAMERA] Erreur de lecture."
            )
            break

        height, width = frame.shape[:2]

        detector.setInputSize(
            (width, height)
        )

        _, faces = detector.detect(frame)

        count = 0
        best_result = None

        if faces is not None:

            for face in faces:

                detection_confidence = float(
                    face[-1]
                )

                if detection_confidence < DETECTION_THRESHOLD:
                    continue

                result = recognize_face(
                    frame,
                    face
                )

                if result is None:
                    continue

                count += 1

                x, y, w, h = map(
                    int,
                    face[:4]
                )

                if (
                    best_result is None
                    or result["similarity"]
                    > best_result["similarity"]
                ):
                    best_result = result

                authorized = (
                    result["identity"] == "AUTHORIZED"
                )

                color = (
                    (0, 255, 0)
                    if authorized
                    else (0, 255, 255)
                )

                cv2.rectangle(
                    frame,
                    (x, y),
                    (x + w, y + h),
                    color,
                    2
                )

                label = (
                    f"{result['name']} "
                    f"({result['similarity']:.2f})"
                )

                cv2.putText(
                    frame,
                    label,
                    (x, max(y - 10, 20)),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.55,
                    color,
                    2
                )

        # ==================================
        # 9. ENVOI AU BACKEND
        # ==================================

        identity = "NOT_AVAILABLE"

        if best_result is not None:

            identity = best_result["identity"]

            send_identity(
                best_result["name"],
                best_result["similarity"]
            )

        # Aucun visage detecte :
        # aucun envoi au backend.

        # ==================================
        # 10. MOTEUR DE MENACE
        # ==================================

        threat = calculate_threat(
            anomaly=False,
            motion=False,
            distance=None,
            identity=identity
        )

        # ==================================
        # 11. INTERFACE SENTINEL-X
        # ==================================

        status = (
            "PRESENCE DETECTEE"
            if count > 0
            else "AUCUNE PRESENCE"
        )

        cv2.putText(
            frame,
            "SENTINEL-X GUARDIAN",
            (20, 40),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.8,
            (0, 255, 0),
            2
        )

        cv2.putText(
            frame,
            f"Visages detectes : {count}",
            (20, 75),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.7,
            (255, 255, 255),
            2
        )

        cv2.putText(
            frame,
            f"Camera : {status}",
            (20, 110),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.6,
            (0, 255, 255) if count > 0 else (0, 255, 0),
            2
        )

        cv2.putText(
            frame,
            f"Menace : {threat['level']} ({threat['score']}/100)",
            (20, 145),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.6,
            (255, 255, 255),
            2
        )

        cv2.putText(
            frame,
            f"Type : {threat['alert_type']}",
            (20, 180),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.6,
            (255, 255, 255),
            2
        )

        cv2.putText(
            frame,
            f"Identite : {identity}",
            (20, 215),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.6,
            (0, 255, 255) if count > 0 else (255, 255, 255),
            2
        )

        # ==================================
        # 12. AFFICHAGE VIDEO
        # ==================================

        cv2.imshow(
            "SENTINEL-X | Guardian",
            frame
        )

        if cv2.waitKey(1) & 0xFF == ord("q"):
            break

finally:

    camera.release()
    cv2.destroyAllWindows()

print("SENTINEL-X Guardian arrete.")
