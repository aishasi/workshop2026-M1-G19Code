"""SENTINEL-X Data IA V3 experimentale. Lancer sur port 8002.
API compatible avec /predict du backend; ne pas connecter en production sans validation.
"""
from collections import deque
from threading import Lock
import math
import numpy as np
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from sklearn.ensemble import IsolationForest
from sklearn.preprocessing import StandardScaler
from threat_engine import calculate_threat

app = FastAPI(title='SENTINEL-X IA Data V3 - test')

class Mesure(BaseModel):
    temperature: float
    humidity: float
    distance_cm: float = 0.0
    motion_detected: bool = False
    gas_detected: bool = False
    status: str = 'NORMAL'

WINDOW = 6
MIN_TRAIN = 100
MAX_BASELINE = 3000
# Les seuils ci-dessous sont des garde-fous de demo, pas des seuils industriels.
TEMP_RANGE = (-20.0, 80.0)
HUM_RANGE = (0.0, 100.0)

raw = deque(maxlen=WINDOW)
baseline = deque(maxlen=MAX_BASELINE)
model = None
scaler = None
counter = 0
lock = Lock()


def valid_environment(m):
    return (math.isfinite(m.temperature) and math.isfinite(m.humidity)
            and TEMP_RANGE[0] <= m.temperature <= TEMP_RANGE[1]
            and HUM_RANGE[0] <= m.humidity <= HUM_RANGE[1]
            and m.temperature != 0 and m.humidity != 0)


def features(temp, humidity):
    raw.append((temp, humidity))
    if len(raw) < WINDOW:
        return None
    t = [x[0] for x in raw]
    h = [x[1] for x in raw]
    return [temp, humidity, t[-1]-t[-2], h[-1]-h[-2],
            float(np.mean(t)), float(np.mean(h))]


def train_once():
    global model, scaler
    x = np.asarray(baseline, dtype=float)
    new_scaler = StandardScaler().fit(x)
    new_model = IsolationForest(n_estimators=200, contamination=0.01,
                                random_state=42).fit(new_scaler.transform(x))
    scaler, model = new_scaler, new_model


@app.post('/predict')
def predict(m: Mesure):
    global counter
    with lock:
        counter += 1
        environmental_valid = valid_environment(m)
        anomaly = False
        decision = None
        confidence = None
        state = 'invalid_measurement' if not environmental_valid else 'learning'
        if environmental_valid:
            f = features(m.temperature, m.humidity)
            if f is not None:
                if model is None:
                    # Construire une baseline sur des mesures sans alerte explicite.
                    # A valider sur le terrain avant tout usage de securite.
                    if not m.gas_detected and m.status.upper() == 'NORMAL':
                        baseline.append(f)
                    if len(baseline) >= MIN_TRAIN:
                        train_once()  # gel du modele apres l'apprentissage initial
                if model is not None:
                    transformed = scaler.transform([f])
                    decision = float(model.decision_function(transformed)[0])
                    anomaly = bool(model.predict(transformed)[0] == -1)
                    # Indicateur heuristique, NON une probabilite.
                    confidence = round(min(1.0, abs(decision) * 5), 2)
                    state = 'ready'
        distance = m.distance_cm if math.isfinite(m.distance_cm) and m.distance_cm >= 2 else None
        threat = calculate_threat(anomaly=anomaly, motion=m.motion_detected,
                                  distance=distance, identity='NOT_AVAILABLE')
        if m.gas_detected:
            threat['score'] = max(threat['score'], 80)
            threat['level'] = 'CRITIQUE'
            threat['alert_type'] = 'GAZ'
            threat['reasons'].insert(0, 'Signal gaz actif (seuil capteur a calibrer)')
        dashboard = {'NORMAL':'FAIBLE','VIGILANCE':'MOYEN',
                     'ALERTE':'ELEVE','CRITIQUE':'ELEVE'}[threat['level']]
        return {'anomaly': anomaly, 'score': round(decision,4) if decision is not None else None,
                'confidence': confidence, 'threat_score': threat['score'],
                'threat_level': dashboard, 'level': threat['level'],
                'alert_type': threat['alert_type'], 'reasons': threat['reasons'],
                'model': 'IsolationForest adapte - baseline gelee' if model is not None else 'apprentissage',
                'ai_state': state, 'samples': len(baseline)}


@app.get('/')
def home():
    return {'status':'SENTINEL-X IA V3 test', 'mesures':counter,
            'modele_pret':model is not None, 'baseline_samples':len(baseline)}
