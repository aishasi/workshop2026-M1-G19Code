import json


def calculate_threat(
    anomaly=False,
    motion=False,
    distance=None,
    identity="NOT_AVAILABLE"
):
    score = 0
    reasons = []
    intrusion = False
    environmental = anomaly is True

    if motion:
        score += 15
        reasons.append("Mouvement détecté")

    if distance is not None:
        if distance < 50:
            score += 25
            reasons.append("Présence très proche")
        elif distance < 100:
            score += 15
            reasons.append("Présence proche")

    if identity == "UNKNOWN":
        score += 35
        reasons.append("Profil inconnu")

    if environmental:
        score += 35
        reasons.append("Anomalie environnementale détectée")

    intrusion = (
        identity == "UNKNOWN"
        and motion
        and distance is not None
        and distance < 100
    )

    score = min(score, 100)

    if environmental and intrusion:
        level = "CRITIQUE"
        score = max(score, 75)
        alert_type = "COMBINEE"

    elif environmental:
        level = "ALERTE"
        score = max(score, 50)
        alert_type = "ENVIRONNEMENT"

    elif intrusion:
        level = "ALERTE"
        score = max(score, 50)
        alert_type = "INTRUSION"

    else:
        if score >= 75:
            level = "CRITIQUE"
        elif score >= 50:
            level = "ALERTE"
        elif score >= 25:
            level = "VIGILANCE"
        else:
            level = "NORMAL"

        alert_type = "PRESENCE" if score > 0 else "AUCUNE"

    return {
        "score": score,
        "level": level,
        "alert_type": alert_type,
        "reasons": reasons
    }


if __name__ == "__main__":
    result = calculate_threat(
        anomaly=True,
        motion=False,
        distance=200,
        identity="NOT_AVAILABLE"
    )

    print(json.dumps(result, indent=2, ensure_ascii=False))