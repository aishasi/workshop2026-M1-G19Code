
"""
SENTINEL-X - Serveur IA de l'equipe Data (V2)

Utilise le moteur de menace de l'equipe
(threat_engine.calculate_threat)
et une Isolation Forest avec les memes variables temporelles
que la V3 (variations + moyennes glissantes).

Adapte aux vrais capteurs du Raspberry Pi :
- Temperature
- Humidite
- Distance
- Mouvement
- Gaz binaire

Le gaz est traite comme une alerte directe.

La camera transmet l'identite via le backend :
- AUTHORIZED
- UNKNOWN
- NOT_AVAILABLE

Lancement :
uvicorn ia_server_v2:app --host 0.0.0.0 --port 8001
"""

from collections import deque

import numpy as np
from fastapi import FastAPI
from pydantic import BaseModel
from sklearn.ensemble import IsolationForest
from sklearn.preprocessing import StandardScaler

from threat_engine import calculate_threat


# ==========================================
# 1. INITIALISATION FASTAPI
# ==========================================

app = FastAPI(
    title="SENTINEL-X - IA equipe Data (V2)"
)


# ==========================================
# 2. FORMAT DES DONNEES DU BACKEND
# ==========================================

class Mesure(BaseModel):
    temperature: float
    humidity: float
    distance_cm: float = 0.0
    motion_detected: bool = False
    gas_detected: bool = False
    status: str = "NORMAL"
    identity: str = "NOT_AVAILABLE"


# ==========================================
# 3. PARAMETRES DU MODELE IA
# ==========================================

WINDOW = 6
MIN_TRAIN = 100
RETRAIN_EVERY = 60

brut = deque(maxlen=WINDOW)

features_hist = deque(maxlen=3000)

modele = None
scaler = None

compteur = 0


# ==========================================
# 4. CALCUL DES VARIABLES TEMPORELLES
# ==========================================

def calculer_features(temp, hum):
    """
    Calcule les variables temporelles utilisees
    pour la detection des anomalies.
    """

    brut.append((temp, hum))

    if len(brut) < WINDOW:
        return None

    t = [b[0] for b in brut]
    h = [b[1] for b in brut]

    return [
        temp,
        hum,
        t[-1] - t[-2],
        h[-1] - h[-2],
        float(np.mean(t)),
        float(np.mean(h)),
    ]


# ==========================================
# 5. ENTRAINEMENT ISOLATION FOREST
# ==========================================

def entrainer():
    global modele, scaler

    X = np.array(features_hist)

    scaler = StandardScaler().fit(X)

    modele = IsolationForest(
        n_estimators=200,
        contamination=0.01,
        random_state=42
    ).fit(
        scaler.transform(X)
    )


# ==========================================
# 6. PREDICTION IA
# ==========================================

@app.post("/predict")
def predict(m: Mesure):

    global compteur

    compteur += 1

    # --------------------------------------
    # 6.1 Detection anomalie environnementale
    # --------------------------------------

    anomalie = False
    score_ia = 0.0
    confiance = 0.0

    feats = calculer_features(
        m.temperature,
        m.humidity
    )

    if feats is not None:

        features_hist.append(feats)

        if len(features_hist) >= MIN_TRAIN:

            if (
                modele is None
                or compteur % RETRAIN_EVERY == 0
            ):
                entrainer()

            Xs = scaler.transform([feats])

            score_ia = float(
                modele.decision_function(Xs)[0]
            )

            anomalie = bool(
                modele.predict(Xs)[0] == -1
            )

            confiance = round(
                min(1.0, abs(score_ia) * 5),
                2
            )

    # --------------------------------------
    # 6.2 Validation de la distance
    # --------------------------------------

    # Distance inferieure a 2 cm :
    # mesure consideree comme invalide

    distance = (
        m.distance_cm
        if m.distance_cm >= 2
        else None
    )

    # --------------------------------------
    # 6.3 Analyse de menace avec identite
    # --------------------------------------

    # Seules les valeurs AUTHORIZED et UNKNOWN
    # sont transmises au moteur de menace.
    # Toute autre valeur devient NOT_AVAILABLE.

    threat = calculate_threat(
        anomaly=anomalie,
        motion=m.motion_detected,
        distance=distance,
        identity=m.identity if m.identity in ("AUTHORIZED", "UNKNOWN") else "NOT_AVAILABLE",
    )

    # --------------------------------------
    # 6.4 Detection du gaz
    # --------------------------------------

    # Le capteur MQ du Raspberry Pi renvoie
    # une information binaire.
    # Une detection declenche une alerte critique.

    if m.gas_detected:

        threat["score"] = max(
            threat["score"],
            80
        )

        threat["level"] = "CRITIQUE"

        threat["alert_type"] = "GAZ"

        threat["reasons"].insert(
            0,
            "Gaz detecte"
        )

    # --------------------------------------
    # 6.5 Correspondance dashboard
    # --------------------------------------

    niveau_dashboard = {
        "NORMAL": "FAIBLE",
        "VIGILANCE": "MOYEN",
        "ALERTE": "ELEVE",
        "CRITIQUE": "ELEVE",
    }[threat["level"]]

    # --------------------------------------
    # 6.6 Reponse au backend
    # --------------------------------------

    return {
        "anomaly": anomalie,
        "score": round(score_ia, 4),
        "confidence": confiance,
        "threat_score": threat["score"],
        "threat_level": niveau_dashboard,
        "level": threat["level"],
        "alert_type": threat["alert_type"],
        "reasons": threat["reasons"],
        "model": (
            "IsolationForest V3 (temps reel)"
            if modele is not None
            else "apprentissage"
        ),
    }


# ==========================================
# 7. ETAT DU SERVEUR IA
# ==========================================

@app.get("/")
def accueil():

    return {
        "status": "IA SENTINEL-X V2 en ligne",
        "mesures": compteur,
        "modele_pret": modele is not None,
    }
