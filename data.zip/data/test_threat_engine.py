from threat_engine import calculate_threat

scenarios = [
    {
        "name": "Situation normale",
        "params": {
            "anomaly": False,
            "motion": False,
            "distance": 200,
            "identity": "AUTHORIZED"
        },
        "expected": "NORMAL"
    },
    {
        "name": "Mouvement simple",
        "params": {
            "anomaly": False,
            "motion": True,
            "distance": 78,
            "identity": "AUTHORIZED"
        },
        "expected": "VIGILANCE"
    },
    {
        "name": "Intrusion potentielle",
        "params": {
            "anomaly": False,
            "motion": True,
            "distance": 78,
            "identity": "UNKNOWN"
        },
        "expected": "ALERTE"
    },
    {
        "name": "Intrusion + anomalie environnementale",
        "params": {
            "anomaly": True,
            "motion": True,
            "distance": 42,
            "identity": "UNKNOWN"
        },
        "expected": "CRITIQUE"
    }
]

print("\n=== TESTS SENTINEL-X ===\n")

for scenario in scenarios:
    result = calculate_threat(**scenario["params"])

    passed = result["level"] == scenario["expected"]

    print(f"Scénario : {scenario['name']}")
    print(f"Score    : {result['score']}/100")
    print(f"Niveau   : {result['level']}")
    print(f"Résultat : {'OK' if passed else 'ÉCHEC'}")
    print("-" * 40)

    assert passed, f"Échec : {scenario['name']}"

print("\nTous les tests sont réussis !")


print("\n=== TESTS DES TYPES D'ALERTES ===\n")

additional_scenarios = [
    {
        "name": "Anomalie environnementale seule",
        "params": {
            "anomaly": True,
            "motion": False,
            "distance": 200,
            "identity": "NOT_AVAILABLE"
        },
        "expected_level": "ALERTE",
        "expected_type": "ENVIRONNEMENT"
    },
    {
        "name": "Intrusion sans anomalie environnementale",
        "params": {
            "anomaly": False,
            "motion": True,
            "distance": 78,
            "identity": "UNKNOWN"
        },
        "expected_level": "ALERTE",
        "expected_type": "INTRUSION"
    },
    {
        "name": "Intrusion et anomalie environnementale",
        "params": {
            "anomaly": True,
            "motion": True,
            "distance": 42,
            "identity": "UNKNOWN"
        },
        "expected_level": "CRITIQUE",
        "expected_type": "COMBINEE"
    }
]

for scenario in additional_scenarios:
    result = calculate_threat(**scenario["params"])

    assert result["level"] == scenario["expected_level"]
    assert result["alert_type"] == scenario["expected_type"]

    print(f"{scenario['name']} : OK")
    print(f"Score : {result['score']}/100")
    print(f"Niveau : {result['level']}")
    print(f"Type : {result['alert_type']}")
    print("-" * 40)

print("Tous les tests supplémentaires sont réussis !")