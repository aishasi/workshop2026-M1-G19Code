
import cv2
import requests
import time
from pathlib import Path
from threat_engine import calculate_threat

# ==========================================
# 1. CONFIGURATION SENTINEL-X
# ==========================================

BACKEND_URL = "http://192.168.137.141:8000/api/v1/identity"

SEND_INTERVAL = 2
_last_send = 0

print("=== SENTINEL-X GUARDIAN ===")
print("Initialisation de la detection...")


# ==========================================
# 2. ENVOI IDENTITE AU BACKEND
# ==========================================

def send_identity(name, similarity):
    global _last_send

    # Un envoi maximum toutes les 2 secondes
    now = time.monotonic()

    if now - _last_send < SEND_INTERVAL:
        return

    payload = {
        "identity": (
            "UNKNOWN"
            if name == "INCONNU"
            else "AUTHORIZED"
        ),
        "name": name,
        "similarity": round(float(similarity), 2),
    }

    try:
        response = requests.post(
            BACKEND_URL,
            json=payload,
            timeout=0.5
        )

        response.raise_for_status()

        _last_send = now

        print(
            "[BACKEND] Identite envoyee : "
            f"{payload['identity']} | "
            f"Nom : {payload['name']} | "
            f"Similarite : {payload['similarity']}"
        )

    except requests.RequestException as error:
        print(f"[BACKEND] Erreur : {error}")


# ==========================================
# 3. CHARGEMENT DU MODELE YUNET
# ==========================================

BASE_DIR = Path(__file__).resolve().parent

MODEL_PATH = (
    BASE_DIR
    / "models"
    / "camera"
    / "face_detection_yunet_2023mar.onnx"
)

if not MODEL_PATH.exists():
    raise FileNotFoundError(
        f"Modele introuvable : {MODEL_PATH}"
    )

detector = cv2.FaceDetectorYN.create(
    str(MODEL_PATH),
    "",
    (320, 320),
    0.9,
    0.3,
    5000
)


# ==========================================
# 4. INITIALISATION CAMERA
# ==========================================

camera = cv2.VideoCapture(
    0,
    cv2.CAP_DSHOW
)

if not camera.isOpened():
    raise RuntimeError(
        "Camera inaccessible."
    )

print("Camera active !")
print("Appuie sur Q pour quitter.")


# ==========================================
# 5. SURVEILLANCE EN TEMPS REEL
# ==========================================

try:
    while True:

        success, frame = camera.read()

        if not success:
            print("Erreur de lecture camera.")
            break

        height, width = frame.shape[:2]

        detector.setInputSize(
            (width, height)
        )

        # Detection des visages
        _, faces = detector.detect(frame)

        count = (
            0
            if faces is None
            else len(faces)
        )

        # ==================================
        # 6. ANALYSE DES VISAGES
        # ==================================

        face_detected = False

        # Aucun resultat par defaut
        best_result = None

        if faces is not None:

            for face in faces:

                # Coordonnees du visage
                x, y, w, h = map(
                    int,
                    face[:4]
                )

                # Confiance de detection YuNet
                detection_confidence = float(
                    face[-1]
                )

                # Ignorer les detections
                # insuffisamment fiables
                if detection_confidence < 0.9:
                    continue

                face_detected = True

                # YuNet ne reconnait pas les noms.
                # Ce resultat indique uniquement
                # qu'un visage a ete detecte.
                result = {
                    "name": "INCONNU",
                    "similarity": 0.0,
                    "detection_confidence": detection_confidence
                }

                if (
                    best_result is None
                    or detection_confidence
                    > best_result["detection_confidence"]
                ):
                    best_result = result

                # Rectangle autour du visage
                cv2.rectangle(
                    frame,
                    (x, y),
                    (x + w, y + h),
                    (0, 255, 255),
                    2
                )

                cv2.putText(
                    frame,
                    "VISAGE DETECTE - INCONNU",
                    (x, max(y - 10, 20)),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.5,
                    (0, 255, 255),
                    2
                )

        # ==================================
        # 7. ENVOI UNIQUEMENT SI VISAGE
        # ==================================

        identity = "NOT_AVAILABLE"

        if best_result is not None:

            name = best_result["name"]
            similarity = best_result["similarity"]

            identity = "UNKNOWN"

            # Aucun appel lorsque la camera
            # ne detecte aucun visage valide
            send_identity(
                name,
                similarity
            )

        # ==================================
        # 8. MOTEUR DE MENACE
        # ==================================

        threat = calculate_threat(
            anomaly=False,
            motion=False,
            distance=None,
            identity=identity
        )

        # ==================================
        # 9. ETAT DE LA CAMERA
        # ==================================

        status = (
            "PRESENCE DETECTEE"
            if face_detected
            else "AUCUNE PRESENCE"
        )

        # ==================================
        # 10. INTERFACE SENTINEL-X
        # ==================================

        cv2.putText(
            frame,
            "SENTINEL-X GUARDIAN",
            (20, 40),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.8,
            (0, 255, 0),
            2
        )

        cv2.putText(
            frame,
            f"Visages detectes : {count}",
            (20, 75),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.7,
            (255, 255, 255),
            2
        )

        cv2.putText(
            frame,
            f"Camera : {status}",
            (20, 110),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.6,
            (
                (0, 255, 255)
                if face_detected
                else (0, 255, 0)
            ),
            2
        )

        cv2.putText(
            frame,
            f"Menace : {threat['level']} ({threat['score']}/100)",
            (20, 145),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.6,
            (255, 255, 255),
            2
        )

        cv2.putText(
            frame,
            f"Type : {threat['alert_type']}",
            (20, 180),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.6,
            (255, 255, 255),
            2
        )

        cv2.putText(
            frame,
            f"Identite : {identity}",
            (20, 215),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.6,
            (
                (0, 255, 255)
                if face_detected
                else (255, 255, 255)
            ),
            2
        )

        # ==================================
        # 11. AFFICHAGE VIDEO
        # ==================================

        cv2.imshow(
            "SENTINEL-X | Guardian",
            frame
        )

        if cv2.waitKey(1) & 0xFF == ord("q"):
            break

finally:

    camera.release()
    cv2.destroyAllWindows()

print("SENTINEL-X Guardian arrete.")
