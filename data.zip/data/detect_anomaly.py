import json
import sys
from pathlib import Path

import joblib
import pandas as pd

# --------------------------------------------------
# Configuration
# --------------------------------------------------

BASE_DIR = Path(__file__).resolve().parent

MODEL_PATH = BASE_DIR / "models" / "isolation_forest_v3.pkl"
SCALER_PATH = BASE_DIR / "models" / "scaler_v3.pkl"
HISTORY_PATH = BASE_DIR / "data" / "live_history.csv"

FEATURES = [
    "temperature",
    "humidity",
    "gas",
    "temp_change",
    "gas_change",
    "humidity_change",
    "temp_rolling_mean",
    "gas_rolling_mean",
    "humidity_rolling_mean",
]

SENSOR_FIELDS = ["temperature", "humidity", "gas"]

model = joblib.load(MODEL_PATH)
scaler = joblib.load(SCALER_PATH)


# --------------------------------------------------
# Analyse d'une mesure
# --------------------------------------------------

def analyze_measure(measure):
    # Validation des données reçues
    if not isinstance(measure, dict):
        raise ValueError("La mesure doit être un objet JSON.")

    clean_measure = {}

    for field in SENSOR_FIELDS:
        if field not in measure:
            raise ValueError(f"Champ manquant : {field}")

        value = float(measure[field])

        if not pd.notna(value) or not (-float("inf") < value < float("inf")):
            raise ValueError(f"Valeur invalide : {field}")

        clean_measure[field] = value

    # Charger l'historique réel, s'il existe
    if HISTORY_PATH.exists():
        history = pd.read_csv(HISTORY_PATH)
        history = history[SENSOR_FIELDS].tail(5).copy()
    else:
        history = pd.DataFrame(columns=SENSOR_FIELDS)

    # Ajouter la nouvelle mesure
    new_row = pd.DataFrame([clean_measure])

    data = pd.concat(
        [history, new_row],
        ignore_index=True
    )

    # Sauvegarder l'historique pour le prochain appel
    # Si moins de 6 mesures, attendre avant de prédire
    if len(data) < 6:
        data.to_csv(HISTORY_PATH, index=False)

        return {
            "status": "INITIALISATION",
            "anomaly": None,
            "score": None,
            "message": f"Historique : {len(data)}/6 mesures"
        }

    # --------------------------------------------------
    # Variables temporelles identiques à la V3
    # --------------------------------------------------

    data["temp_change"] = data["temperature"].diff()
    data["gas_change"] = data["gas"].diff()
    data["humidity_change"] = data["humidity"].diff()

    data["temp_rolling_mean"] = (
        data["temperature"].rolling(window=6).mean()
    )

    data["gas_rolling_mean"] = (
        data["gas"].rolling(window=6).mean()
    )

    data["humidity_rolling_mean"] = (
        data["humidity"].rolling(window=6).mean()
    )

    current = data.iloc[-1:]
    X = current[FEATURES]

    X_scaled = scaler.transform(X)

    # --------------------------------------------------
    # Prédiction IA
    # --------------------------------------------------

    prediction = int(model.predict(X_scaled)[0])
    score = float(model.decision_function(X_scaled)[0])

    anomaly = prediction == -1

    # Sauvegarder uniquement les 5 dernières mesures brutes
    data[SENSOR_FIELDS].tail(5).to_csv(
        HISTORY_PATH,
        index=False
    )

    return {
        "status": "ANOMALIE" if anomaly else "NORMAL",
        "anomaly": anomaly,
        "score": round(score, 4),
        "temperature": clean_measure["temperature"],
        "humidity": clean_measure["humidity"],
        "gas": clean_measure["gas"]
    }


# --------------------------------------------------
# Entrée JSON
# --------------------------------------------------

if __name__ == "__main__":
    try:
        if len(sys.argv) > 1:
            measure = json.loads(sys.argv[1])
        else:
            # Mesure de test
            measure = {
                "temperature": 34.5,
                "humidity": 49.0,
                "gas": 290
            }

        result = analyze_measure(measure)

        print(json.dumps(result, indent=2, ensure_ascii=False))

    except (ValueError, TypeError, json.JSONDecodeError) as error:
        print(json.dumps({
            "status": "ERREUR",
            "message": str(error)
        }, ensure_ascii=False))
        sys.exit(1)