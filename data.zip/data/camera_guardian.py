import json
import time
import urllib.request
from pathlib import Path

import cv2

# Backend SENTINEL-X : lecture seule (requêtes GET).
BACKEND_URL = "http://192.168.137.141:8000"
REFRESH_SECONDS = 1.0
TIMEOUT_SECONDS = 1.0
STALE_SECONDS = 10.0

BASE_DIR = Path(__file__).resolve().parent
MODEL_PATH = BASE_DIR / "models" / "camera" / "face_detection_yunet_2023mar.onnx"


def get_json(path):
    with urllib.request.urlopen(BACKEND_URL + path, timeout=TIMEOUT_SECONDS) as response:
        return json.load(response)


def draw_text(frame, text, y, color=(255, 255, 255), scale=0.56):
    cv2.putText(frame, text, (20, y), cv2.FONT_HERSHEY_SIMPLEX, scale, (0, 0, 0), 4, cv2.LINE_AA)
    cv2.putText(frame, text, (20, y), cv2.FONT_HERSHEY_SIMPLEX, scale, color, 2, cv2.LINE_AA)


def main():
    if not MODEL_PATH.exists():
        raise FileNotFoundError(f"Modele YuNet introuvable : {MODEL_PATH}")

    detector = cv2.FaceDetectorYN.create(str(MODEL_PATH), "", (320, 320), 0.8, 0.3, 5000)
    camera = cv2.VideoCapture(0, cv2.CAP_DSHOW)
    if not camera.isOpened():
        raise RuntimeError("Camera inaccessible")

    last_poll = 0.0
    measurements = None
    ai = None
    backend_ok = False
    last_error = ""

    print("=== SENTINEL-X GUARDIAN ===")
    print("Lecture seule du backend :", BACKEND_URL)
    print("Appuie sur Q pour quitter.")

    try:
        while True:
            ok, frame = camera.read()
            if not ok:
                print("Erreur de lecture camera")
                break

            now = time.monotonic()
            if now - last_poll >= REFRESH_SECONDS:
                last_poll = now
                try:
                    measurements = get_json("/api/v1/data")
                    ai = get_json("/api/v1/ai/status?history=0")
                    backend_ok = True
                    last_error = ""
                except (OSError, ValueError, KeyError) as exc:
                    backend_ok = False
                    last_error = type(exc).__name__

            h, w = frame.shape[:2]
            detector.setInputSize((w, h))
            _, faces = detector.detect(frame)
            count = 0 if faces is None else len(faces)

            if faces is not None:
                for face in faces:
                    x, y, fw, fh = map(int, face[:4])
                    cv2.rectangle(frame, (x, y), (x + fw, y + fh), (0, 255, 0), 2)
                    # Éviter les étiquettes au-dessus du visage qui recouvrent le panneau.

            # Panneau sombre lisible même devant une scène lumineuse.
            overlay = frame.copy()
            panel_h = min(h, 270)
            cv2.rectangle(overlay, (0, 0), (min(w, 520), panel_h), (18, 22, 27), -1)
            cv2.addWeighted(overlay, 0.72, frame, 0.28, 0, frame)

            draw_text(frame, "SENTINEL-X GUARDIAN", 30, (90, 255, 90), 0.72)
            draw_text(frame, f"Visages detectes : {count}", 63)
            draw_text(frame, "Camera : PRESENCE VISUELLE" if count else "Camera : AUCUN VISAGE", 94,
                      (0, 220, 255) if count else (110, 230, 110))

            if not backend_ok:
                draw_text(frame, "Backend : INJOIGNABLE", 130, (0, 0, 255))
                draw_text(frame, "Menace : INDISPONIBLE", 161, (0, 0, 255))
                draw_text(frame, "Ne pas assimiler a NORMAL", 192, (0, 220, 255))
                if last_error:
                    draw_text(frame, f"Erreur reseau : {last_error}", 223)
            else:
                temp = measurements.get("temperature") if measurements else None
                hum = measurements.get("humidity") if measurements else None
                motion = bool(measurements.get("motion_detected")) if measurements else False
                gas = bool(measurements.get("gas_detected")) if measurements else False

                draw_text(frame, f"PIR : {'OUI' if motion else 'NON'} | Gaz : {'OUI' if gas else 'NON'}", 125)
                if temp is not None and hum is not None:
                    draw_text(frame, f"Temperature : {temp:.1f} C | Humidite : {hum:.1f} %", 155)

                # Le niveau vient du moteur Data, pas de la seule detection de visage.
                source = ai.get("source") if isinstance(ai, dict) else None
                predicted_at = ai.get("predicted_at") if isinstance(ai, dict) else None
                age = None
                if predicted_at:
                    try:
                        from datetime import datetime
                        age = (datetime.now() - datetime.fromisoformat(predicted_at)).total_seconds()
                    except ValueError:
                        pass
                fresh = age is not None and -5 <= age <= STALE_SECONDS
                if source == "data" and fresh and ai.get("threat_score") is not None:
                    score = int(ai["threat_score"])
                    level = str(ai.get("level") or "INCONNU").upper()
                    if level not in ("NORMAL", "VIGILANCE", "ALERTE", "CRITIQUE"):
                        level = "INCONNU"
                    color = {"NORMAL": (80, 220, 80), "VIGILANCE": (0, 220, 255),
                             "ALERTE": (0, 140, 255), "CRITIQUE": (0, 0, 255)}.get(level, (255, 255, 255))
                    draw_text(frame, f"Menace : {level} ({score}/100)", 188, color, 0.64)
                    draw_text(frame, f"Type : {ai.get('alert_type', 'INCONNU')}", 220)
                    draw_text(frame, "Source : IA equipe Data", 252, (180, 240, 180), 0.5)
                else:
                    draw_text(frame, "Menace : NON DISPONIBLE", 188, (0, 220, 255))
                    draw_text(frame, "Prediction IA absente/ancienne", 220)
                    draw_text(frame, f"Source : {source or 'aucune'}", 252)

            cv2.imshow("SENTINEL-X | Guardian", frame)
            if cv2.waitKey(1) & 0xFF == ord("q"):
                break
    finally:
        camera.release()
        cv2.destroyAllWindows()
        print("SENTINEL-X Guardian arrete.")


if __name__ == "__main__":
    main()
