import os
import json
import psycopg2
import paho.mqtt.client as mqtt
from fastapi import FastAPI
from pydantic import BaseModel


app = FastAPI(
    title="SENTINEL-X API",
    version="1.0.0"
)


# PostgreSQL
DB_HOST = os.getenv("DB_HOST", "postgres")
DB_NAME = os.getenv("DB_NAME", "sentinel")
DB_USER = os.getenv("DB_USER", "sentinel")
DB_PASSWORD = os.getenv("DB_PASSWORD", "sentinel_dev")
DB_PORT = os.getenv("DB_PORT", "5432")

# MQTT sécurisé
MQTT_HOST = os.getenv("MQTT_HOST", "mosquitto")
MQTT_PORT = int(os.getenv("MQTT_PORT", "8883"))
MQTT_TOPIC = "sentinel/alerts"

MQTT_USER = os.getenv("MQTT_USER", "esp8266_device")
MQTT_PASSWORD = os.getenv("MQTT_PASSWORD")
MQTT_CA_CERT = os.getenv(
    "MQTT_CA_CERT",
    "/etc/ssl/sentinelx/ca.crt"
)


class Alert(BaseModel):
    type: str
    message: str


def get_db_connection():
    return psycopg2.connect(
        host=DB_HOST,
        database=DB_NAME,
        user=DB_USER,
        password=DB_PASSWORD,
        port=DB_PORT
    )


def init_database():
    connection = get_db_connection()
    cursor = connection.cursor()

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS alerts (
            id SERIAL PRIMARY KEY,
            type VARCHAR(100) NOT NULL,
            message TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)

    connection.commit()
    cursor.close()
    connection.close()


def publish_mqtt(alert_id, alert):
    if not MQTT_PASSWORD:
        raise RuntimeError("MQTT_PASSWORD non configuré")

    client = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2)

    client.username_pw_set(MQTT_USER, MQTT_PASSWORD)
    client.tls_set(ca_certs=MQTT_CA_CERT)

    client.connect(MQTT_HOST, MQTT_PORT, 60)
    client.loop_start()

    message = {
        "alert_id": alert_id,
        "type": alert.type,
        "message": alert.message
    }

    try:
        info = client.publish(MQTT_TOPIC, json.dumps(message), qos=1)
        info.wait_for_publish(timeout=10)

        if not info.is_published():
            raise RuntimeError("Publication MQTT non confirmée")
    finally:
        client.disconnect()
        client.loop_stop()


@app.on_event("startup")
def startup():
    init_database()


@app.get("/")
def root():
    return {
        "status": "ok",
        "service": "SENTINEL-X API"
    }


@app.get("/api/v1/health")
def health():
    return {
        "status": "healthy"
    }


@app.post("/api/v1/alerts")
def create_alert(alert: Alert):

    # 1. Enregistrement PostgreSQL
    connection = get_db_connection()
    cursor = connection.cursor()

    cursor.execute(
        """
        INSERT INTO alerts (type, message)
        VALUES (%s, %s)
        RETURNING id, created_at
        """,
        (alert.type, alert.message)
    )

    result = cursor.fetchone()

    connection.commit()
    cursor.close()
    connection.close()

    # 2. Publication MQTT
    publish_mqtt(result[0], alert)

    return {
        "status": "received",
        "alert_id": result[0],
        "created_at": result[1],
        "mqtt_topic": MQTT_TOPIC
    }