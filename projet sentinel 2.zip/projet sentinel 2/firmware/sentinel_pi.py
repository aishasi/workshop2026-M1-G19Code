#!/usr/bin/env python3
"""
SENTINEL-X - Firmware Raspberry Pi (remplace main.cpp de l'ESP8266)
Lit DHT22 + PIR + ultrason HC-SR04 et envoie au backend FastAPI.

Cablage (numeros de broches PHYSIQUES du Raspberry Pi) :
  DHT22   : +   -> broche 1 (3.3V)  | out  -> broche 7 (GPIO4)   | -   -> broche 6
  PIR     : (brochage a identifier) | OUT  -> broche 11 (GPIO17) | GND -> broche 9
  HC-SR04 : VCC -> broche 4 (5V)    | Trig -> broche 16 (GPIO23) | GND -> broche 20
            Echo -> pont diviseur (1k / 2k) -> broche 18 (GPIO24)  ATTENTION : jamais en direct (5V)

Installation sur le Pi :
  sudo apt install -y python3-pip libgpiod2
  pip3 install adafruit-circuitpython-dht requests --break-system-packages

Lancement :
  python3 sentinel_pi.py
"""

import time
import requests
import board
import adafruit_dht
from gpiozero import MotionSensor, DistanceSensor, PWMOutputDevice, DigitalInputDevice

# ---- Configuration ----
SERVER_URL = "http://192.168.137.141:8000/api/v1/alerts"  # IP du PC qui fait tourner uvicorn
INTERVAL_S = 2
USE_SONAR = True   # True seulement si le HC-SR04 est branche
BUZZER_PIN = 22
GAS_PIN = 27
TEMP_ALERT = 30.0       # °C
HUM_ALERT = 70.0        # %
DIST_ALERT = 50.0       # cm : objet plus proche -> alerte

# ---- Capteurs ----
dht = adafruit_dht.DHT22(board.D4)                            # GPIO4
pir = MotionSensor(17)                                        # GPIO17
sonar = None
if USE_SONAR:
    # queue_len=1 + partial=True : pas de blocage en attendant que la file de mesures se remplisse
    sonar = DistanceSensor(echo=24, trigger=23, max_distance=2,
                           queue_len=1, partial=True)         # GPIO24 / GPIO23, 2 m max
gas = DigitalInputDevice(GAS_PIN, pull_up=False)             # GPIO27, sortie DO du capteur MQ
buzzer = PWMOutputDevice(BUZZER_PIN, frequency=2000)          # GPIO22, buzzer passif
buzzer.off()

last_temp, last_hum = None, None

print(f"SENTINEL-X Pi demarre -> envoi vers {SERVER_URL}")

try:
    while True:
        # Le DHT22 echoue parfois sur une lecture : on garde la derniere valeur valide
        try:
            t = dht.temperature
            h = dht.humidity
            if t is not None and h is not None:
                last_temp, last_hum = t, h
        except RuntimeError:
            pass

        distance_cm = 0.0
        if USE_SONAR:
            try:
                distance_cm = round(sonar.distance * 100, 1)   # gpiozero renvoie des metres
            except Exception:
                distance_cm = 0.0
            if distance_cm < 2.0:      # le HC-SR04 ne mesure pas sous 2 cm : valeur invalide
                distance_cm = 0.0
        motion = 1 if pir.motion_detected else 0

        # Objet trop proche du sonar : compte comme un mouvement (0.0 = pas de mesure)
        too_close = 2.0 <= distance_cm < DIST_ALERT
        if too_close:
            motion = 1

        # Capteur MQ : la sortie DO passe a 0 quand le gaz depasse le seuil reglé sur le module
        gas_detected = (gas.value == 0)

        # Alerte si seuil depasse (0.0 = pas de mesure, on l'ignore)
        temp = float(last_temp or 0)
        hum = float(last_hum or 0)
        alert = (temp != 0.0 and temp > TEMP_ALERT) or (hum != 0.0 and hum > HUM_ALERT) or too_close or bool(motion) or gas_detected

        if alert:
            for _ in range(2):          # 2 bips courts
                buzzer.value = 0.5
                time.sleep(0.2)
                buzzer.value = 0
                time.sleep(0.2)
        else:
            buzzer.off()

        # ATTENTION : ces noms de champs doivent etre IDENTIQUES a AlertPayload dans backend/main.py
        payload = {
            "temperature": temp,
            "humidity": hum,
            "distance_cm": distance_cm,
            "motion_detected": bool(motion),
            "gas_detected": bool(gas_detected),
            "status": "ALERTE" if alert else "NORMAL",
        }

        try:
            r = requests.post(SERVER_URL, json=payload, timeout=5)
            print(f"POST -> {r.status_code} | {payload['status']} | distance_cm={distance_cm} | {payload}")
            if r.status_code == 422:
                print("  422 : les champs ne correspondent pas a AlertPayload ->", r.text)
        except requests.RequestException as e:
            print(f"POST -> echec ({e.__class__.__name__}) : serveur injoignable ? | {payload['status']} | distance_cm={distance_cm}")

        time.sleep(INTERVAL_S)
except KeyboardInterrupt:
    print("Arret demande (Ctrl+C)")
finally:
    buzzer.off()
    buzzer.close()
