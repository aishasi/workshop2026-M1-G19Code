#include <Arduino.h>
#include <ESP8266WiFi.h>
#include <ESP8266HTTPClient.h>
#include <WiFiClient.h>
#include <ArduinoJson.h>
#include <DHT.h>

// Configuration Wi-Fi
const char* ssid = "Simofatha";
const char* password = "Moha123456";

// URL du serveur FastAPI (Remplace l'IP par celle de ton PC)
const char* serverUrl = "http://172.20.10.8:80000/api/v1/alerts";

// Capteur DHT11
#define DHTPIN D4
#define DHTTYPE DHT11
DHT dht(DHTPIN, DHTTYPE);

// Capteurs Gaz et Présence
#define GAS_PIN A0
#define PIR_PIN D5

void setup() {
  Serial.begin(115200);
  dht.begin();
  pinMode(PIR_PIN, INPUT);

  // Connexion au réseau Wi-Fi
  WiFi.begin(ssid, password);
  Serial.print("Connexion au Wi-Fi");
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  Serial.println("\nWi-Fi connecté !");
  Serial.print("Adresse IP de l'ESP8266 : ");
  Serial.println(WiFi.localIP());
}

void loop() {
  if (WiFi.status() == WL_CONNECTED) {
    WiFiClient client;
    HTTPClient http;

    // 1. Lecture des données capteurs
    float temp = dht.readTemperature();
    float hum = dht.readHumidity();
    int gas = analogRead(GAS_PIN);
    bool motion = digitalRead(PIR_PIN);

    // Vérification de la lecture DHT
    if (isnan(temp) || isnan(hum)) {
      temp = 20.0;
      hum = 50.0;
    }

    // 2. Création du payload JSON
    StaticJsonDocument<200> doc;
    doc["temperature"] = temp;
    doc["humidity"] = hum;
    doc["gas_level"] = gas;
    doc["motion_detected"] = motion;
    doc["status"] = (gas > 400 || motion) ? "ALERT" : "NORMAL";

    String jsonPayload;
    serializeJson(doc, jsonPayload);

    // 3. Envoi de la requête POST au serveur Python
    http.begin(client, serverUrl);
    http.addHeader("Content-Type", "application/json");

    int httpResponseCode = http.POST(jsonPayload);

    if (httpResponseCode > 0) {
      Serial.printf("Données envoyées ! Code réponse HTTP : %d\n", httpResponseCode);
    } else {
      Serial.printf("Erreur d'envoi HTTP : %s\n", http.errorToString(httpResponseCode).c_str());
    }

    http.end();
  } else {
    Serial.println("Wi-Fi déconnecté...");
  }

  // Envoi toutes les 3 secondes
  delay(3000);
}