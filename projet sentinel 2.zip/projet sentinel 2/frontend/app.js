// SENTINEL-X - Dashboard
// Toutes les 2 s : interroge l'API FastAPI et met a jour la page affichee.

// ---- Configuration ----
const API = "http://localhost:8000/api/v1";
const REFRESH_MS = 2000;
const PI_IP = "192.168.137.124";
const TEMP_ALERT = 30.0;   // memes seuils que firmware/sentinel_pi.py et backend/main.py
const HUM_ALERT = 70.0;
const DIST_ALERT = 50.0;

const PAGES = {
    overview: ["Vue d'ensemble", "État de la sécurité et des capteurs en un coup d'œil"],
    realtime: ["Surveillance temps réel", "Valeurs des capteurs mises à jour toutes les 2 secondes"],
    ai:       ["Intelligence artificielle", "Détection d'anomalies sur l'historique des mesures"],
    alerts:   ["Alertes", "Journal des événements et statistiques du jour"],
    system:   ["Système", "Câblage, réseau et architecture"],
};

// Petit raccourci pour document.getElementById
const $ = (id) => document.getElementById(id);

async function getJSON(path) {
    const res = await fetch(API + path);
    if (!res.ok) throw new Error(`${path} -> HTTP ${res.status}`);
    return res.json();
}

// "2026-10-08T14:03:12" -> "14:03:12"
const fmtTime = (ts) => (ts ? new Date(ts).toLocaleTimeString("fr-FR") : "--");

// =====================================================================
// Navigation : la barre laterale affiche une section et cache les autres
// =====================================================================
let currentPage = "overview";

function showPage(name) {
    if (!PAGES[name]) name = "overview";
    currentPage = name;
    document.querySelectorAll(".section").forEach((s) => (s.hidden = s.id !== "section-" + name));
    document.querySelectorAll(".nav-link").forEach((a) =>
        a.classList.toggle("active", a.dataset.section === name));
    $("page-title").textContent = PAGES[name][0];
    $("page-subtitle").textContent = PAGES[name][1];
    refresh();
}

// Le lien change l'adresse (#overview, #alerts...) : on affiche la bonne page
window.addEventListener("hashchange", () => showPage(location.hash.slice(1)));

// =====================================================================
// Horloge en direct (chaque seconde)
// =====================================================================
function tickClock() {
    const now = new Date();
    $("clock-time").textContent = now.toLocaleTimeString("fr-FR");
    $("clock-date").textContent = now.toLocaleDateString("fr-FR",
        { weekday: "long", day: "numeric", month: "long", year: "numeric" });
}

// =====================================================================
// Outils d'affichage
// =====================================================================
function setPill(id, text, level) {          // level : "ok" | "warn" | "bad" | ""
    $(id).innerHTML = "";
    const dot = document.createElement("span");
    dot.className = "dot " + level;
    $(id).append(dot, text);
}

function setChip(id, text, level) {
    $(id).textContent = text;
    $(id).className = "chip " + level;
}

// Mini-courbe SVG (ligne + zone coloree en dessous)
function sparkline(svgId, values, color) {
    const svg = $(svgId);
    if (values.length < 2) { svg.innerHTML = ""; return; }
    const W = 120, H = 36, pad = 3;
    let min = Math.min(...values), max = Math.max(...values);
    if (max - min < 1e-6) { min -= 1; max += 1; }      // courbe plate : on la centre
    const pts = values.map((v, i) => [
        (i / (values.length - 1)) * W,
        H - pad - ((v - min) / (max - min)) * (H - 2 * pad),
    ]);
    const line = pts.map((p) => p.join(",")).join(" ");
    svg.innerHTML =
        `<polygon points="0,${H} ${line} ${W},${H}" fill="${color}" opacity="0.15"/>` +
        `<polyline points="${line}" fill="none" stroke="${color}" stroke-width="1.6" ` +
        `vector-effect="non-scaling-stroke" stroke-linejoin="round"/>`;
}

// Garde au plus n points, repartis regulierement (evite de surcharger les graphiques)
function downsample(arr, n) {
    if (arr.length <= n) return arr;
    const step = arr.length / n;
    return Array.from({ length: n }, (_, i) => arr[Math.floor(i * step)]);
}

function levelClass(level) {
    return "badge badge-" + level;
}

const LEVEL_LABEL = { critique: "Critique", majeure: "Majeure", mineure: "Mineure", information: "Info" };

function renderEvents(listId, events) {
    const ul = $(listId);
    ul.innerHTML = "";
    if (!events.length) {
        ul.innerHTML = '<li class="empty">Aucun événement</li>';
        return;
    }
    for (const e of events) {
        const li = document.createElement("li");
        const badge = document.createElement("span");
        badge.className = levelClass(e.level);
        badge.textContent = LEVEL_LABEL[e.level] || e.level;
        const msg = document.createElement("span");
        msg.textContent = e.message;
        const time = document.createElement("span");
        time.className = "event-time";
        time.textContent = fmtTime(e.ts);
        li.append(badge, msg, time);
        ul.append(li);
    }
}

// =====================================================================
// Calculs a partir de la derniere mesure
// =====================================================================
function activeThreats(d) {
    const list = [];
    if (d.gas_detected) list.push("Gaz détecté");
    if (d.motion_detected) list.push("Mouvement détecté");
    if (d.distance_cm >= 2 && d.distance_cm < DIST_ALERT) list.push(`Objet à ${d.distance_cm.toFixed(0)} cm`);
    if (d.temperature !== 0 && d.temperature > TEMP_ALERT) list.push("Température élevée");
    if (d.humidity !== 0 && d.humidity > HUM_ALERT) list.push("Humidité élevée");
    return list;
}

// Niveaux de menace : texte affiche + couleur (memes noms que le moteur de l'equipe Data)
const THREAT_LEVEL = {
    FAIBLE: ["Faible", "var(--green)"],
    MOYEN:  ["Moyen", "var(--orange)"],
    ELEVE:  ["Élevé", "var(--red)"],
};

// Threat score 0-100 : mouvement +30, gaz +40, distance < 50 cm +20, temp/humidite +10
function threatScore(d) {
    let score = 0;
    if (d.motion_detected) score += 30;
    if (d.gas_detected) score += 40;
    if (d.distance_cm >= 2 && d.distance_cm < DIST_ALERT) score += 20;
    if ((d.temperature !== 0 && d.temperature > TEMP_ALERT) || (d.humidity !== 0 && d.humidity > HUM_ALERT)) score += 10;
    return Math.min(score, 100);
}

// Etat de chaque capteur : [texte affiche, texte de la pastille, couleur, en alerte ?]
// Partage par la Vue d'ensemble et la Surveillance temps reel.
function sensorStates(d) {
    const tempHigh = d.temperature !== 0 && d.temperature > TEMP_ALERT;
    const humHigh = d.humidity !== 0 && d.humidity > HUM_ALERT;
    const distClose = d.distance_cm >= 2 && d.distance_cm < DIST_ALERT;
    let dist;
    if (!d.distance_cm) dist = ["--", "Pas de mesure", "", false];
    else if (distClose) dist = [d.distance_cm.toFixed(0), "Proche", "bad", true];
    else dist = [d.distance_cm.toFixed(0), "Normal", "ok", false];
    return {
        temp: !d.temperature ? ["--", "Pas de mesure", "", false]
            : [d.temperature.toFixed(1), tempHigh ? "Élevée" : "Normale", tempHigh ? "bad" : "ok", tempHigh],
        hum: !d.humidity ? ["--", "Pas de mesure", "", false]
            : [d.humidity.toFixed(1), humHigh ? "Élevée" : "Normale", humHigh ? "bad" : "ok", humHigh],
        dist,
        motion: d.motion_detected ? ["DÉTECTÉ", "Actif", "bad", true] : ["Aucun", "Calme", "ok", false],
        gas: d.gas_detected ? ["DÉTECTÉ", "Danger", "bad", true] : ["Aucun", "Normal", "ok", false],
    };
}

// Remplit une carte capteur : prefix "ov" ou "rt", key "temp", "hum"...
function renderSensorCard(prefix, key, state) {
    const [value, chipText, level, alert] = state;
    $(`${prefix}-${key}`).textContent = value;
    setChip(`${prefix}-chip-${key}`, chipText, level);
    $(`${prefix}-card-${key}`).classList.toggle("alert", alert);
}

// =====================================================================
// Elements communs : barre laterale + pastilles de l'en-tete
// =====================================================================
function renderCommon(stats, ai) {
    const online = !!(stats && stats.online);
    $("device-dot").className = "dot " + (online ? "ok" : "bad");
    $("device-status").textContent = online ? "En ligne" : "Hors ligne";
    $("device-ip").textContent = PI_IP;

    if (!stats) setPill("pill-system", "Système : serveur injoignable", "bad");
    else setPill("pill-system", "Système : " + (online ? "en ligne" : "boîtier hors ligne"), online ? "ok" : "bad");

    if (!ai) setPill("pill-ai", "IA : indisponible", "");
    else if (ai.status === "NORMAL") setPill("pill-ai", "IA : normal", "ok");
    else if (ai.status === "ANOMALIE") setPill("pill-ai", "IA : anomalie", "bad");
    else setPill("pill-ai", "IA : apprentissage", "warn");
}

// =====================================================================
// Page 1 : Vue d'ensemble
// =====================================================================
const ovChart = new Chart($("ov-chart"), {
    type: "line",
    data: {
        labels: [],
        datasets: [
            { label: "Température (°C)", data: [], borderColor: "#f59e0b", backgroundColor: "rgba(245,158,11,0.1)",
              fill: true, tension: 0.3, pointRadius: 0, yAxisID: "yT" },
            { label: "Humidité (%)", data: [], borderColor: "#3b82f6", backgroundColor: "rgba(59,130,246,0.1)",
              fill: true, tension: 0.3, pointRadius: 0, yAxisID: "yH" },
        ],
    },
    options: {
        animation: false,
        responsive: true,
        maintainAspectRatio: false,
        interaction: { mode: "index", intersect: false },
        scales: {
            x:  { ticks: { color: "#8a9bb8", maxTicksLimit: 8 }, grid: { color: "#1f2c4a" } },
            yT: { position: "left",  ticks: { color: "#f59e0b" }, grid: { color: "#1f2c4a" } },
            yH: { position: "right", ticks: { color: "#3b82f6" }, grid: { drawOnChartArea: false } },
        },
        plugins: { legend: { labels: { color: "#e6edf7" } } },
    },
});

function renderOverview(d, stats, events, history, ai) {
    // --- Etat global + bouclier ---
    const isAlert = d.status === "ALERTE";
    const online = !!(stats && stats.online);
    const threats = activeThreats(d);
    const panel = $("state-panel");
    panel.classList.toggle("alert", isAlert);
    panel.classList.toggle("offline", !online && !isAlert);
    $("state-value").textContent = isAlert ? "ALERTE" : "NORMAL";
    let reasons = threats.length ? threats.join(" · ") : "Aucune menace détectée";
    if (!online) reasons = "Boîtier hors ligne — dernières valeurs connues. " + reasons;
    $("state-reasons").textContent = reasons;

    // --- Jauge threat score : celui du moteur Data s'il repond, sinon le calcul local ---
    const fromData = ai && ai.source === "data" && ai.threat_score != null;
    const score = fromData ? Math.max(0, Math.min(100, ai.threat_score)) : threatScore(d);
    let level;   // "FAIBLE" | "MOYEN" | "ELEVE"
    if (fromData && THREAT_LEVEL[ai.threat_level]) level = ai.threat_level;
    else level = score >= 60 ? "ELEVE" : score >= 30 ? "MOYEN" : "FAIBLE";
    const [levelText, color] = THREAT_LEVEL[level];
    $("gauge-fg").setAttribute("stroke-dasharray", `${score} 100`);
    $("gauge-fg").style.stroke = color;
    $("gauge-value").textContent = score;
    $("gauge-level").textContent = levelText;
    $("gauge-level").style.color = color;
    $("gauge-source").textContent = fromData ? "Source : moteur IA équipe Data" : "Source : calcul local";

    // --- Resume du jour ---
    if (stats) {
        $("sum-critique").textContent = stats.alerts_today.critique;
        $("sum-majeure").textContent = stats.alerts_today.majeure;
        $("sum-mineure").textContent = stats.alerts_today.mineure;
        $("sum-motions").textContent = stats.motions_today;
        $("sum-last").textContent = fmtTime(stats.last_measurement);
    }

    // --- 4 cartes capteurs ---
    const st = sensorStates(d);
    for (const key of ["temp", "hum", "dist", "motion"]) renderSensorCard("ov", key, st[key]);

    // --- Mini-courbes (60 points sur les 30 dernieres minutes) ---
    if (history) {
        const h = downsample(history, 60);
        sparkline("spark-temp", h.filter((m) => m.temperature).map((m) => m.temperature), "#f59e0b");
        sparkline("spark-hum", h.filter((m) => m.humidity).map((m) => m.humidity), "#3b82f6");
        sparkline("spark-dist", h.filter((m) => m.distance_cm).map((m) => m.distance_cm), "#22d3ee");
        sparkline("spark-motion", h.map((m) => (m.motion_detected ? 1 : 0)), "#a78bfa");

        // --- Graphique temperature / humidite ---
        const c = downsample(history.filter((m) => m.temperature && m.humidity), 180);
        ovChart.data.labels = c.map((m) => fmtTime(m.ts));
        ovChart.data.datasets[0].data = c.map((m) => m.temperature);
        ovChart.data.datasets[1].data = c.map((m) => m.humidity);
        ovChart.update();
    }

    // --- 5 derniers evenements ---
    if (events) renderEvents("ov-events", events);
}

// =====================================================================
// Page 2 : Surveillance temps reel
// =====================================================================
let rtMinutes = 5;   // periode affichee sur le graphique (boutons 1 / 5 / 30 min)

const rtChart = new Chart($("rt-chart"), {
    type: "line",
    data: {
        labels: [],
        datasets: [
            { label: "Température (°C)", data: [], borderColor: "#f59e0b", tension: 0.3, pointRadius: 0, yAxisID: "yT" },
            { label: "Humidité (%)", data: [], borderColor: "#3b82f6", tension: 0.3, pointRadius: 0, yAxisID: "yH" },
            { label: "Distance (cm)", data: [], borderColor: "#22d3ee", tension: 0.2, pointRadius: 0, yAxisID: "yD" },
        ],
    },
    options: {
        animation: false,
        responsive: true,
        maintainAspectRatio: false,
        interaction: { mode: "index", intersect: false },
        scales: {
            x:  { ticks: { color: "#8a9bb8", maxTicksLimit: 8 }, grid: { color: "#1f2c4a" } },
            yT: { position: "left",  ticks: { color: "#f59e0b" }, grid: { color: "#1f2c4a" } },
            yH: { position: "right", ticks: { color: "#3b82f6" }, grid: { drawOnChartArea: false } },
            yD: { position: "right", ticks: { color: "#22d3ee" }, grid: { drawOnChartArea: false }, min: 0 },
        },
        plugins: { legend: { labels: { color: "#e6edf7" } } },
    },
});

// Boutons 1 min / 5 min / 30 min
document.querySelectorAll("#rt-range button").forEach((btn) =>
    btn.addEventListener("click", () => {
        rtMinutes = Number(btn.dataset.min);
        document.querySelectorAll("#rt-range button").forEach((b) => b.classList.toggle("active", b === btn));
        refresh();
    }));

// Liste des capteurs avec leur broche
const SENSORS = [
    { name: "DHT22 (température / humidité)", pin: "GPIO4" },
    { name: "PIR HC-SR501 (mouvement)",        pin: "GPIO17" },
    { name: "HC-SR04 (distance)",              pin: "Trig GPIO23 · Echo GPIO24" },
    { name: "Capteur de gaz MQ",               pin: "DO GPIO27" },
    { name: "Buzzer passif",                   pin: "GPIO22" },
];

// Connecte / Deconnecte :
// - boitier hors ligne -> tout est deconnecte
// - DHT22 et HC-SR04 : connectes s'ils ont donne une vraie valeur (non nulle) dans les 30 dernieres secondes
// - PIR, gaz, buzzer : impossible a verifier a distance, on suit l'etat du boitier
function sensorConnections(online, history) {
    const since = Date.now() - 30000;
    const recent = (history || []).filter((m) => new Date(m.ts).getTime() >= since);
    return [
        online && recent.some((m) => m.temperature !== 0),
        online,
        online && recent.some((m) => m.distance_cm !== 0),
        online,
        online,
    ];
}

function renderRealtime(d, stats, history) {
    // --- 5 cartes ---
    const st = sensorStates(d);
    for (const key of ["temp", "hum", "gas", "motion", "dist"]) renderSensorCard("rt", key, st[key]);

    // --- Graphique sur la periode choisie (0 = pas de mesure -> trou dans la courbe) ---
    if (history) {
        const c = downsample(history, 240);
        rtChart.data.labels = c.map((m) => fmtTime(m.ts));
        rtChart.data.datasets[0].data = c.map((m) => m.temperature || null);
        rtChart.data.datasets[1].data = c.map((m) => m.humidity || null);
        rtChart.data.datasets[2].data = c.map((m) => m.distance_cm || null);
        rtChart.update();
    }

    // --- Jauge de distance (echelle 0-200 cm) ---
    const marker = $("rt-dist-marker");
    const readout = $("rt-dist-readout");
    if (d.distance_cm) {
        marker.hidden = false;
        marker.style.left = Math.min(d.distance_cm / 200, 1) * 100 + "%";
        readout.textContent = `${d.distance_cm.toFixed(0)} cm — ${st.dist[1]}`;
        readout.style.color = st.dist[2] === "bad" ? "var(--red)" : "var(--green)";
    } else {
        marker.hidden = true;
        readout.textContent = "Pas de mesure";
        readout.style.color = "var(--muted)";
    }

    // --- Statut des capteurs ---
    const connected = sensorConnections(!!(stats && stats.online), history);
    const ul = $("rt-status");
    ul.innerHTML = "";
    SENSORS.forEach((s, i) => {
        const li = document.createElement("li");
        const label = document.createElement("div");
        label.textContent = s.name;
        const pin = document.createElement("span");
        pin.className = "pin";
        pin.textContent = s.pin;
        label.append(pin);
        const state = document.createElement("span");
        state.className = "state";
        state.style.color = connected[i] ? "var(--green)" : "var(--red)";
        const dot = document.createElement("span");
        dot.className = "dot " + (connected[i] ? "ok" : "bad");
        state.append(dot, connected[i] ? "Connecté" : "Déconnecté");
        li.append(label, state);
        ul.append(li);
    });
}

// =====================================================================
// Page 3 : IA
// =====================================================================
const ENGINE_LABEL = {
    local: "Moteur : local",
    data: "Moteur : équipe Data",
    "local (secours)": "Moteur : local (secours)",
};

let aiHistLabels = [];   // NORMAL / ANOMALIE pour chaque point (affiche au survol)

const aiChart = new Chart($("ai-chart"), {
    type: "line",
    data: {
        labels: [],
        datasets: [{
            label: "Score d'anomalie", data: [], borderColor: "#a78bfa", backgroundColor: "rgba(167,139,250,0.1)",
            fill: true, tension: 0.3, pointRadius: [], pointBackgroundColor: "#ef4444", pointBorderWidth: 0,
        }],
    },
    options: {
        animation: false,
        responsive: true,
        maintainAspectRatio: false,
        interaction: { mode: "index", intersect: false },
        scales: {
            x: { ticks: { color: "#8a9bb8", maxTicksLimit: 8 }, grid: { color: "#1f2c4a" } },
            y: { suggestedMin: 0.3, suggestedMax: 0.8, ticks: { color: "#8a9bb8" }, grid: { color: "#1f2c4a" } },
        },
        plugins: {
            legend: { display: false },
            tooltip: { callbacks: { afterLabel: (ctx) => aiHistLabels[ctx.dataIndex] || "" } },
        },
    },
});

function setBar(id, ratio, color) {
    $(id).style.width = Math.max(0, Math.min(1, ratio)) * 100 + "%";
    if (color) $(id).style.background = color;
}

// Identite (camera de l'equipe Data), lue sur GET /api/v1/identity.
// "Non disponible" = aucune camera, ou plus de visage depuis 10 s.
const IDENTITY_LABEL = {
    AUTHORIZED: ["Autorisé", "authorized"],
    UNKNOWN: ["Inconnu", "unknown"],
    NOT_AVAILABLE: ["Non disponible", ""],
};

function renderIdentity(id) {
    const state = (id && id.identity) || "NOT_AVAILABLE";
    const [text, cls] = IDENTITY_LABEL[state] || IDENTITY_LABEL.NOT_AVAILABLE;
    $("ai-identity").classList.remove("authorized", "unknown");
    if (cls) $("ai-identity").classList.add(cls);
    $("ai-id-state").textContent = text;
    $("ai-id-hint").hidden = state !== "NOT_AVAILABLE";
    $("ai-id-name").textContent = (id && id.name) || (state === "UNKNOWN" ? "Inconnu" : "--");
    $("ai-id-sim").textContent = id && id.similarity != null
        ? Math.max(0, Math.round(id.similarity * 100)) + " %" : "--";
    $("ai-id-seen").textContent = id && id.last_seen ? fmtTime(id.last_seen) : "--";
}

// Petit badge sur la Vue d'ensemble
function renderIdentityBadge(id) {
    const state = (id && id.identity) || "NOT_AVAILABLE";
    const badge = $("ov-identity");
    badge.classList.remove("authorized", "unknown");
    const dot = badge.querySelector(".dot");
    if (state === "AUTHORIZED") {
        badge.classList.add("authorized");
        dot.className = "dot ok";
        $("ov-identity-text").textContent = "Identité : Autorisé" + (id.name ? " · " + id.name : "");
    } else if (state === "UNKNOWN") {
        badge.classList.add("unknown");
        dot.className = "dot bad";
        $("ov-identity-text").textContent = "Identité : Inconnu";
    } else {
        dot.className = "dot";
        $("ov-identity-text").textContent = "Identité : aucune caméra active";
    }
}

function renderAI(ai) {
    const box = $("ai-result");
    box.classList.remove("anomaly", "pending", "learning", "off");

    if (!ai) {
        box.classList.add("off");
        $("ai-label").textContent = "INDISPONIBLE";
        $("ai-explain").textContent = "Le serveur ne répond pas.";
        return;
    }

    const learning = ai.status === "apprentissage en cours";
    $("ai-learning").hidden = !learning;
    $("ai-engine").textContent = ENGINE_LABEL[ai.source || ai.engine] || ai.engine;
    $("ai-model").textContent = ai.model || "--";
    $("ai-threat").textContent = ai.threat_score != null
        ? `${ai.threat_score}/100 — ${(THREAT_LEVEL[ai.threat_level] || [ai.threat_level])[0]}` : "—";
    $("ai-predicted").textContent = fmtTime(ai.predicted_at);
    $("ai-conf-hint").textContent = ai.source === "data"
        ? "Certitude du moteur de l'équipe Data" : "Certitude de l'IA sur ce résultat";

    // Niveau, type d'alerte et raisons (fournis par le moteur Data ; masques s'ils sont vides)
    const LEVEL_BADGE = { NORMAL: "badge-ok", VIGILANCE: "badge-mineure", ALERTE: "badge-majeure", CRITIQUE: "badge-critique" };
    $("ai-level-row").hidden = !ai.level;
    $("ai-level").textContent = ai.level || "";
    $("ai-level").className = "badge " + (LEVEL_BADGE[ai.level] || "badge-information");
    const hasType = ai.alert_type && ai.alert_type !== "AUCUNE";
    $("ai-type-row").hidden = !hasType;
    $("ai-type").textContent = hasType ? ai.alert_type : "";
    const reasonsList = ai.reasons || [];
    $("ai-reasons-row").hidden = !reasonsList.length;
    $("ai-reasons").innerHTML = "";
    for (const r of reasonsList) {
        const li = document.createElement("li");
        li.textContent = r;
        $("ai-reasons").append(li);
    }

    if (learning) {
        box.classList.add("learning");
        $("ai-label").textContent = "APPRENTISSAGE";
        $("ai-explain").textContent = "L'IA observe les mesures pour apprendre ce qui est habituel.";
        $("ai-learning-text").textContent =
            `${ai.samples} / ${ai.samples_needed} mesures valides reçues. L'IA donnera son avis dès ${ai.samples_needed} mesures.`;
        setBar("ai-learning-bar", ai.samples / ai.samples_needed);
        $("ai-score").textContent = "--";
        $("ai-conf").textContent = "--";
        setBar("ai-score-bar", 0);
        setBar("ai-conf-bar", 0);
    } else {
        const anomaly = ai.status === "ANOMALIE";
        box.classList.toggle("anomaly", anomaly);
        box.classList.toggle("pending", !anomaly && ai.streak > 0);
        $("ai-label").textContent = ai.status;
        const reasons = (ai.reasons || []).length ? " Raisons : " + ai.reasons.join(" · ") + "." : "";
        if (ai.source === "data") {
            // Le moteur Data donne son avis directement (pas de confirmation sur 3 mesures)
            if (ai.model === "apprentissage") {
                box.classList.add("learning");
                $("ai-label").textContent = "APPRENTISSAGE";
                $("ai-explain").textContent = "Le moteur de l'équipe Data apprend encore les mesures habituelles.";
            } else {
                $("ai-explain").textContent = (anomaly
                    ? "Le moteur de l'équipe Data signale une anomalie."
                    : "Le moteur de l'équipe Data ne signale rien d'anormal.") + reasons;
            }
        } else if (anomaly) $("ai-explain").textContent =
            `${ai.confirm_needed} mesures inhabituelles d'affilée : changement anormal confirmé.`;
        else if (ai.streak > 0) $("ai-explain").textContent =
            `Anomalie possible (${ai.streak}/${ai.confirm_needed}) : à confirmer sur les prochaines mesures.`;
        else $("ai-explain").textContent = "Les mesures et leur évolution ressemblent à l'habitude.";
        $("ai-score").textContent = ai.score != null ? ai.score.toFixed(3) : "--";
        setBar("ai-score-bar", ai.score ?? 0, anomaly ? "var(--red)" : "var(--green)");
        // Confiance 0 (moteur Data en apprentissage) ou absente -> "--"
        const conf = ai.confidence > 0 ? ai.confidence : null;
        $("ai-conf").textContent = conf != null ? Math.round(conf * 100) + " %" : "--";
        setBar("ai-conf-bar", conf ?? 0);
    }

    // --- Historique (le serveur l'envoie du plus recent au plus ancien) ---
    const hist = (ai.history || []).slice().reverse();
    const anomalies = hist.filter((h) => h.label === "ANOMALIE").length;
    $("ai-hist-summary").textContent = hist.length
        ? `— ${anomalies} anomalie(s) sur les ${hist.length} dernières prédictions` : "";
    aiChart.data.labels = hist.map((h) => fmtTime(h.ts));
    aiChart.data.datasets[0].data = hist.map((h) => h.score);
    aiChart.data.datasets[0].pointRadius = hist.map((h) => (h.label === "ANOMALIE" ? 4 : 0));
    aiHistLabels = hist.map((h) => h.label);
    aiChart.update();

    // 10 dernieres predictions
    const ul = $("ai-list");
    ul.innerHTML = "";
    const last = (ai.history || []).slice(0, 10);
    if (!last.length) ul.innerHTML = '<li class="empty">Aucune prédiction</li>';
    for (const h of last) {
        const li = document.createElement("li");
        const badge = document.createElement("span");
        badge.className = "badge " + (h.label === "ANOMALIE" ? "badge-critique" : "badge-ok");
        badge.textContent = h.label;
        const score = document.createElement("span");
        score.textContent = h.score != null ? `score ${h.score.toFixed(3)}` : "";
        const time = document.createElement("span");
        time.className = "event-time";
        time.textContent = fmtTime(h.ts);
        li.append(badge, score, time);
        ul.append(li);
    }
}

// =====================================================================
// Page 4 : Alertes
// =====================================================================
let alLevel = "";          // filtre du journal ("" = tous les niveaux)
const AL_LIMIT = 200;      // nb max d'evenements affiches

const TYPE_LABEL = {
    gaz: "Gaz", mouvement: "Présence", distance: "Distance", temperature: "Température",
    humidite: "Humidité", normal: "Retour à la normale", connexion: "Connexion", visage: "Visage",
};
const TYPE_UNIT = { distance: " cm", temperature: " °C", humidite: " %" };

// Duree d'une presence (en secondes) : 65 -> "1 min 05 s"
function fmtDuration(sec) {
    if (sec < 2) return "< 2 s";
    if (sec < 60) return `${sec} s`;
    if (sec < 3600) return `${Math.floor(sec / 60)} min ${String(sec % 60).padStart(2, "0")} s`;
    if (sec < 86400) return `${Math.floor(sec / 3600)} h ${String(Math.floor(sec % 3600 / 60)).padStart(2, "0")} min`;
    return `${Math.floor(sec / 86400)} j ${Math.floor(sec % 86400 / 3600)} h`;
}

function fmtValue(e) {
    if (e.value == null) return "—";
    if (e.type === "mouvement") return fmtDuration(e.value);   // duree de la presence
    if (e.type === "visage") return `similarité ${Math.round(e.value * 100)} %`;
    return e.value.toFixed(1) + (TYPE_UNIT[e.type] || "");
}

// Boutons de filtre Tous / Critique / Majeure / Mineure / Information
document.querySelectorAll("#al-filter button").forEach((btn) =>
    btn.addEventListener("click", () => {
        alLevel = btn.dataset.level;
        document.querySelectorAll("#al-filter button").forEach((b) => b.classList.toggle("active", b === btn));
        refresh();
    }));

// Exporter : le navigateur telecharge le fichier CSV genere par le serveur
$("al-export").addEventListener("click", () => {
    window.location.href = API + "/events/export";
});

// Vider : demande confirmation, puis supprime tout le journal (pages Alertes et Systeme)
async function clearJournal() {
    if (!confirm("Supprimer définitivement tous les événements du journal ?")) return;
    try {
        const res = await fetch(API + "/events", { method: "DELETE" });
        if (!res.ok) throw new Error("HTTP " + res.status);
        refresh();
    } catch (e) {
        alert("Impossible de vider le journal : " + e.message);
    }
}
$("al-clear").addEventListener("click", clearJournal);

function renderAlerts(stats, events) {
    if (stats) {
        $("al-critique").textContent = stats.alerts_today.critique;
        $("al-majeure").textContent = stats.alerts_today.majeure;
        $("al-mineure").textContent = stats.alerts_today.mineure;
        $("al-total").textContent = stats.events_today;
    }
    if (!events) return;

    const tbody = $("al-log");
    tbody.innerHTML = "";
    if (!events.length) {
        tbody.innerHTML = '<tr><td colspan="5" class="empty">Aucun événement</td></tr>';
    }
    for (const e of events) {
        const tr = document.createElement("tr");
        const cells = [
            new Date(e.ts).toLocaleString("fr-FR"),
            null,                                         // badge (ajoute juste apres)
            TYPE_LABEL[e.type] || e.type,
            e.message,
            fmtValue(e),
        ];
        cells.forEach((text, i) => {
            const td = document.createElement("td");
            if (i === 0) td.className = "time";
            if (i === 1) {
                const badge = document.createElement("span");
                badge.className = levelClass(e.level);
                badge.textContent = LEVEL_LABEL[e.level] || e.level;
                td.append(badge);
            } else {
                td.textContent = text;
            }
            tr.append(td);
        });
        tbody.append(tr);
    }
    $("al-count").textContent = events.length >= AL_LIMIT
        ? `${AL_LIMIT} événements les plus récents affichés — exportez en CSV pour tout voir.`
        : `${events.length} événement(s).`;
}

// =====================================================================
// Page 5 : Systeme (cartes d'etat en direct, le reste de la page est fixe)
// =====================================================================
$("sys-clear").addEventListener("click", clearJournal);

const AI_SOURCE_LABEL = { data: "Équipe Data", local: "Local (IsolationForest)", "local (secours)": "Local (secours)" };

function renderSystem(sys) {
    // --- Raspberry Pi ---
    const piOnline = !!(sys && sys.pi.online);
    setChip("sys-pi-chip", piOnline ? "En ligne" : "Hors ligne", piOnline ? "ok" : "bad");
    $("sys-pi-ip").textContent = (sys && sys.pi.ip) || PI_IP;
    $("sys-pi-last").textContent = sys ? fmtTime(sys.pi.last_seen) : "--";

    // --- Backend ---
    setChip("sys-api-chip", sys ? "Joignable" : "Injoignable", sys ? "ok" : "bad");
    $("sys-api-url").textContent = API.replace("http://", "").replace("/api/v1", "");
    $("sys-version").textContent = sys ? sys.version : "--";
    $("sys-uptime").textContent = sys ? fmtDuration(sys.uptime_s) : "--";
    $("sys-started").textContent = sys ? new Date(sys.started_at).toLocaleString("fr-FR") : "--";

    // --- Moteur IA ---
    if (!sys) {
        setChip("sys-ai-chip", "--", "");
    } else if (sys.ai.source === "local (secours)") {
        setChip("sys-ai-chip", "Secours", "warn");
    } else {
        const ready = sys.ai.state === "pret";
        setChip("sys-ai-chip", ready ? "Modèle prêt" : "Apprentissage", ready ? "ok" : "warn");
    }
    $("sys-ai-engine").textContent = sys ? (AI_SOURCE_LABEL[sys.ai.source] || AI_SOURCE_LABEL[sys.ai.engine]) : "--";
    $("sys-ai-url").textContent = sys ? (sys.ai.url || "— (IA locale)").replace("http://", "") : "--";
    $("sys-ai-model").textContent = (sys && sys.ai.model) || "--";

    // --- Base de donnees ---
    $("sys-db-file").textContent = sys ? `${sys.database.file} · ${sys.database.size_kb} Ko` : "--";
    $("sys-db-measures").textContent = sys ? sys.database.measurements.toLocaleString("fr-FR") : "--";
    $("sys-db-events").textContent = sys ? sys.database.events.toLocaleString("fr-FR") : "--";
}

// =====================================================================
// Rafraichissement : on interroge l'API puis on dessine la page affichee
// =====================================================================
let busy = false;
let pending = false;            // un rafraichissement a ete demande pendant qu'un autre tournait

async function refresh() {
    if (busy) { pending = true; return; }   // evite d'empiler les requetes si le serveur est lent
    busy = true;
    pending = false;
    try {
        // allSettled : si une route echoue, les autres s'affichent quand meme
        const [data, stats, ai, events, history, sys, identity] = (await Promise.allSettled([
            getJSON("/data"),
            getJSON("/stats"),
            getJSON(currentPage === "ai" ? "/ai/status?history=100" : "/ai/status?history=0"),
            currentPage === "overview" ? getJSON("/events?limit=5")
                : currentPage === "alerts" ? getJSON(`/events?limit=${AL_LIMIT}` + (alLevel ? `&level=${alLevel}` : ""))
                : null,
            currentPage === "overview" ? getJSON("/history?minutes=30")
                : currentPage === "realtime" ? getJSON(`/history?minutes=${rtMinutes}`) : null,
            currentPage === "system" ? getJSON("/system") : null,
            currentPage === "ai" || currentPage === "overview" ? getJSON("/identity") : null,
        ])).map((r) => (r.status === "fulfilled" ? r.value : null));

        renderCommon(stats, ai);
        if (data && currentPage === "overview") renderOverview(data, stats, events, history, ai);
        if (data && currentPage === "realtime") renderRealtime(data, stats, history);
        if (currentPage === "ai") { renderAI(ai); renderIdentity(identity); }
        if (currentPage === "overview") renderIdentityBadge(identity);
        if (currentPage === "alerts") renderAlerts(stats, events);
        if (currentPage === "system") renderSystem(sys);
    } catch (e) {
        console.error("Erreur de rafraichissement :", e);
    } finally {
        busy = false;
        if (pending) refresh();   // ex. clic sur un filtre pendant le chargement
    }
}

// ---- Demarrage ----
tickClock();
setInterval(tickClock, 1000);
showPage(location.hash.slice(1) || "overview");
setInterval(refresh, REFRESH_MS);
