import pandas as pd
import matplotlib.pyplot as plt

# Charger les résultats de l'IA
data = pd.read_csv("data/sensor_data_analyzed.csv")

data["timestamp"] = pd.to_datetime(data["timestamp"])

# Récupérer uniquement les anomalies
anomalies = data[data["anomaly"] == -1]

# Graphique
plt.figure(figsize=(14, 6))

# Température complète
plt.plot(
    data["timestamp"],
    data["temperature"],
    label="Température"
)

# Anomalies détectées
plt.scatter(
    anomalies["timestamp"],
    anomalies["temperature"],
    label="Anomalie détectée",
    s=55
)

plt.title("SENTINEL-X - Détection d'anomalies par Isolation Forest")
plt.xlabel("Temps")
plt.ylabel("Température (°C)")

plt.legend()
plt.grid(alpha=0.3)
plt.tight_layout()

plt.show()