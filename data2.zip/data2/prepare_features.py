import pandas as pd

# Charger les données
data = pd.read_csv("data/sensor_data.csv")

# --------------------------------------------------
# Variations entre deux mesures
# --------------------------------------------------

data["temp_change"] = data["temperature"].diff()
data["gas_change"] = data["gas"].diff()
data["humidity_change"] = data["humidity"].diff()

# --------------------------------------------------
# Moyennes glissantes
# fenêtre de 6 mesures = environ 30 secondes
# car une mesure est générée toutes les 5 secondes
# --------------------------------------------------

data["temp_rolling_mean"] = (
    data["temperature"]
    .rolling(window=6)
    .mean()
)

data["gas_rolling_mean"] = (
    data["gas"]
    .rolling(window=6)
    .mean()
)

data["humidity_rolling_mean"] = (
    data["humidity"]
    .rolling(window=6)
    .mean()
)

# Les premières lignes n'ont pas encore assez
# d'historique pour calculer certaines variables.
data = data.dropna().reset_index(drop=True)

# Sauvegarder
data.to_csv(
    "data/sensor_data_features.csv",
    index=False
)

print("Variables temporelles créées !")
print()
print(data.head())

print("\nNombre de mesures :", len(data))

print("\nColonnes disponibles :")
for column in data.columns:
    print("-", column)