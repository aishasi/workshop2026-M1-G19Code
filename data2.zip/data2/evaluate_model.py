import pandas as pd
from sklearn.metrics import confusion_matrix, classification_report

# Charger les résultats
data = pd.read_csv("data/sensor_data_analyzed.csv")

# --------------------------------------------------
# Vérité terrain
# --------------------------------------------------

# Par défaut : normal
data["real_anomaly"] = 0

# Anomalies que nous avions volontairement injectées
data.loc[300:329, "real_anomaly"] = 1
data.loc[700:719, "real_anomaly"] = 1

# --------------------------------------------------
# Prédictions Isolation Forest
# --------------------------------------------------

# Isolation Forest :
#  1 = normal
# -1 = anomalie

# On transforme en :
# 0 = normal
# 1 = anomalie

data["predicted_anomaly"] = (
    data["anomaly"] == -1
).astype(int)

# --------------------------------------------------
# Évaluation
# --------------------------------------------------

print("=== ÉVALUATION SENTINEL-X ===")

print("\nMatrice de confusion :")
print(
    confusion_matrix(
        data["real_anomaly"],
        data["predicted_anomaly"]
    )
)

print("\nRapport de classification :")
print(
    classification_report(
        data["real_anomaly"],
        data["predicted_anomaly"],
        target_names=["Normal", "Anomalie"],
        zero_division=0
    )
)

# Quelques statistiques supplémentaires
real = data["real_anomaly"].sum()
detected = data["predicted_anomaly"].sum()

correct = (
    (data["real_anomaly"] == 1) &
    (data["predicted_anomaly"] == 1)
).sum()

print(f"Anomalies réelles : {real}")
print(f"Alertes générées par l'IA : {detected}")
print(f"Anomalies correctement détectées : {correct}/{real}")


print("\n=== DÉTAIL PAR SCÉNARIO ===")

scenario_1 = data.loc[300:329]
scenario_2 = data.loc[700:719]

detected_1 = scenario_1["predicted_anomaly"].sum()
detected_2 = scenario_2["predicted_anomaly"].sum()

print(
    f"Scénario 1 - Température + gaz : "
    f"{detected_1}/30 détectées"
)

print(
    f"Scénario 2 - Gaz uniquement : "
    f"{detected_2}/20 détectées"
)