import pandas as pd
from sklearn.metrics import confusion_matrix, classification_report

# Charger les résultats V3
data = pd.read_csv("data/sensor_data_analyzed_v3.csv")

# Convertir timestamp
data["timestamp"] = pd.to_datetime(data["timestamp"])

# Vérité terrain
data["real_anomaly"] = 0

# On utilise les HORAIRES des anomalies originales
# plutôt que les numéros de lignes, car la V3 a perdu 5 lignes.

# Scénario 1 : lignes originales 300 à 329
scenario_1_start = pd.Timestamp("2026-10-05 08:25:00")
scenario_1_end = pd.Timestamp("2026-10-05 08:27:25")

# Scénario 2 : lignes originales 700 à 719
scenario_2_start = pd.Timestamp("2026-10-05 08:58:20")
scenario_2_end = pd.Timestamp("2026-10-05 08:59:55")

mask_1 = data["timestamp"].between(
    scenario_1_start,
    scenario_1_end
)

mask_2 = data["timestamp"].between(
    scenario_2_start,
    scenario_2_end
)

data.loc[mask_1 | mask_2, "real_anomaly"] = 1

# Conversion prédiction Isolation Forest
# -1 = anomalie -> 1
#  1 = normal   -> 0
data["predicted_anomaly"] = (
    data["anomaly"] == -1
).astype(int)

# Évaluation
print("=== ÉVALUATION SENTINEL-X V3 ===")

print("\nMatrice de confusion :")
print(
    confusion_matrix(
        data["real_anomaly"],
        data["predicted_anomaly"]
    )
)

print("\nRapport de classification :")
print(
    classification_report(
        data["real_anomaly"],
        data["predicted_anomaly"],
        target_names=["Normal", "Anomalie"],
        zero_division=0
    )
)

real = data["real_anomaly"].sum()
detected = data["predicted_anomaly"].sum()

correct = (
    (data["real_anomaly"] == 1)
    & (data["predicted_anomaly"] == 1)
).sum()

false_positives = (
    (data["real_anomaly"] == 0)
    & (data["predicted_anomaly"] == 1)
).sum()

print(f"\nAnomalies réelles : {real}")
print(f"Alertes générées : {detected}")
print(f"Anomalies correctement détectées : {correct}/{real}")
print(f"Fausses alertes : {false_positives}")

# Résultats par scénario
scenario_1 = data[mask_1]
scenario_2 = data[mask_2]

detected_1 = scenario_1["predicted_anomaly"].sum()
detected_2 = scenario_2["predicted_anomaly"].sum()

print("\n=== DÉTAIL PAR SCÉNARIO ===")

print(
    f"Scénario 1 - Température + gaz : "
    f"{detected_1}/{len(scenario_1)} détectées"
)

print(
    f"Scénario 2 - Gaz uniquement : "
    f"{detected_2}/{len(scenario_2)} détectées"
)