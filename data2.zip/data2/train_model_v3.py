import os
import joblib
import pandas as pd

from sklearn.ensemble import IsolationForest
from sklearn.preprocessing import StandardScaler

# Charger les données enrichies
data = pd.read_csv("data/sensor_data_features.csv")

# Variables utilisées par la V3
features = [
    "temperature",
    "humidity",
    "gas",
    "temp_change",
    "gas_change",
    "humidity_change",
    "temp_rolling_mean",
    "gas_rolling_mean",
    "humidity_rolling_mean"
]

X = data[features]

# Normalisation
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# Modèle Isolation Forest
model = IsolationForest(
    n_estimators=200,
    contamination=0.05,
    random_state=42
)

# Entraînement
model.fit(X_scaled)

# Prédictions
data["anomaly"] = model.predict(X_scaled)

# Score d'anomalie
data["anomaly_score"] = model.decision_function(X_scaled)

# Résultats
nb_anomalies = (data["anomaly"] == -1).sum()

print("=== SENTINEL-X - ISOLATION FOREST V3 ===")
print(f"Nombre de mesures : {len(data)}")
print(f"Anomalies détectées : {nb_anomalies}")

print("\nExemples d'anomalies :")

print(
    data[data["anomaly"] == -1][
        [
            "timestamp",
            "temperature",
            "gas",
            "temp_change",
            "gas_change",
            "anomaly_score"
        ]
    ].head(20)
)

# Sauvegarder séparément la V3
os.makedirs("models", exist_ok=True)

joblib.dump(
    model,
    "models/isolation_forest_v3.pkl"
)

joblib.dump(
    scaler,
    "models/scaler_v3.pkl"
)

data.to_csv(
    "data/sensor_data_analyzed_v3.csv",
    index=False
)

print("\nModèle V3 sauvegardé.")
print("Résultats : data/sensor_data_analyzed_v3.csv")