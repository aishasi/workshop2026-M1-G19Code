import os
import numpy as np
import pandas as pd

# Pour obtenir les mêmes données à chaque exécution
np.random.seed(42)

# Nombre de mesures simulées
n = 1000

# Création des données normales
data = pd.DataFrame({
    "temperature": np.random.normal(24, 1.5, n),
    "humidity": np.random.normal(50, 5, n),
    "gas": np.random.normal(180, 15, n),
    "presence": np.random.choice([0, 1], n, p=[0.85, 0.15]),
    "distance": np.random.normal(150, 20, n)
})


# --------------------------------------------------
# Simulation d'anomalies
# --------------------------------------------------

# Anomalie 1 :
# hausse progressive de température + hausse du gaz
# entre les mesures 300 et 329
data.loc[300:329, "temperature"] += np.linspace(2, 10, 30)
data.loc[300:329, "gas"] += np.linspace(10, 80, 30)

# Anomalie 2 :
# comportement inhabituel du gaz
# entre les mesures 700 et 719
data.loc[700:719, "gas"] += np.linspace(30, 120, 20)


# Ajouter une date/heure à chaque mesure
data.insert(
    0,
    "timestamp",
    pd.date_range(start="2026-10-05 08:00:00", periods=n, freq="5s")
)

# Création du dossier data s'il n'existe pas
os.makedirs("data", exist_ok=True)

# Sauvegarde
data.to_csv("data/sensor_data.csv", index=False)

print("Dataset créé avec succès !")
print()
print(data.head())
print()
print(f"Nombre de mesures : {len(data)}")