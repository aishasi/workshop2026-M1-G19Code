import os
import joblib
import pandas as pd

from sklearn.ensemble import IsolationForest
from sklearn.preprocessing import StandardScaler

# Charger les données
data = pd.read_csv("data/sensor_data.csv")

# Variables utilisées par l'IA
features = [
    "temperature",
    "humidity",
    "gas"
]

X = data[features]

# Normalisation des données
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# Création du modèle Isolation Forest
model = IsolationForest(
    n_estimators=200,
    contamination=0.05,
    random_state=42
)

# Entraînement
model.fit(X_scaled)

# Prédictions
predictions = model.predict(X_scaled)

# Score d'anomalie
scores = model.decision_function(X_scaled)

# Isolation Forest renvoie :
#  1 = normal
# -1 = anomalie
data["anomaly"] = predictions
data["anomaly_score"] = scores

# Affichage
nb_anomalies = (data["anomaly"] == -1).sum()

print("Entraînement terminé !")
print(f"Nombre de mesures : {len(data)}")
print(f"Anomalies détectées : {nb_anomalies}")

print("\nExemples d'anomalies détectées :")
print(
    data[data["anomaly"] == -1][
        ["timestamp", "temperature", "humidity", "gas", "anomaly_score"]
    ].head(20)
)

# Créer le dossier models
os.makedirs("models", exist_ok=True)

# Sauvegarder le modèle ET le scaler
joblib.dump(model, "models/isolation_forest.pkl")
joblib.dump(scaler, "models/scaler.pkl")

# Sauvegarder les résultats
data.to_csv("data/sensor_data_analyzed.csv", index=False)

print("\nModèle sauvegardé dans models/isolation_forest.pkl")
print("Scaler sauvegardé dans models/scaler.pkl")
print("Résultats sauvegardés dans data/sensor_data_analyzed.csv")